import React from 'react'
import zImageOverlayCss from './ZImageOverlay.css?url'
import { BsArrowRight } from "react-icons/bs";
import { Link } from '@remix-run/react';


function ZImageOverlay(props) {
  return (
    <div className='overlay-card' onClick={props.onCardClick}>
      {props.popularityRate > 2 && <div className="ribbon ribbon-top-left"><span>{props.popularityRate > 3 ? 'Most ' : ''}Popular</span></div>}
        <img src={props.thumbnail}></img>
        <Link className="d-none" to={props.linkUrl}></Link>
        {/* <img src='https://images.pexels.com/photos/533769/pexels-photo-533769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'></img> */}

        <div className='img-text-box d-flex justify-content-center'>
            <div>{props.name}</div>
            {/* <div className='d-flex flex-column'>
                <div className='m-mid-text f-w-5 d-flex justify-content-end cursor-pointer' onClick={props.hotelOnClick}>Hotel & Stay <BsArrowRight /></div>
                <div className='m-mid-text f-w-5 d-flex justify-content-end cursor-pointer'>Package <BsArrowRight /></div>
            </div> */}
            
        </div>
    </div>
  )
}

export default ZImageOverlay

export function links() {
  return [{rel:'stylesheet', href:zImageOverlayCss}]
}