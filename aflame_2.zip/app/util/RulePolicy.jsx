 const policyMap = new Map([
    [1,'Restrictions'],
    [2,'Guest Profile'],
    [3,'ID Proof Related'],
    [4,'Food Arrangement'],
    [5,'Smoking/Alcohol consumption Rules'],
    [6,'Pet(s) Related'],
    [7,'Property Accessibility'],
    [8,'Other Rules'],
    [9,'Child & Extra Bed Policy']
 ]);

 const subPolicyMap = new Map([
    [1,'Aadhar and Passport are accepted as ID proof(s)'],
    [2,'Unmarried couples allowed'],
    [3,'Food delivery service is available at the property'],
    [4,'Outside food is not allowed'],
    [5,'Smoking within the premises is allowed'],
    [6,'Alcohol consumption is not allowed within the property premises'],
    [7,'Alcohol consumption is allowed within the property premises'],
    [8,'Pets are not allowed'],
    [9,'Pets are allowed'],
    [10,'There are no pets living on the property'],
    [11,'This property is accessible to guests who use a wheelchair. Guests are requested to carry their own wheelchair.'],
    [12,'Allows private parties or events'],
    [13,'Guests are requested not to invite outside visitors in the room during their stay'],
    [14,'Cancellation Policy ...'],
    [15,'No extra bed will be provided to accommodate any child included in the booking'],
    [16,'An extra bed will be provided to accommodate any additional guest included in the booking for a charge.'],
 ])

export function findPolicy(policyId) {
  return policyMap.get(policyId);
}

export function findSubPolicy(subPolicyId) {
    return subPolicyMap.get(subPolicyId);
  }
