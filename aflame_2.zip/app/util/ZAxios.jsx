import axios from "axios";

  const baseUrl = 'http://localhost:8080/'
  const ZAxios = axios.create({baseURL : baseUrl})


export default ZAxios


export function getHomePageAllStays() {
  return ZAxios.get('stays/top/card');
}

export function getHomePageTourPackageCard() {
  return ZAxios.get('packages/promoted/card');
}

export function getPlacesDetails() {
  return ZAxios.get('places');
}

export function getOffbeatPlacesDetails() {
  return ZAxios.get('places/offbeat');
}

// export function getStaysByPlaceCode(code,priceOption, tagOption) {
//   return ZAxios.get('stays/places/'+code + (priceOption ? '?price='+priceOption : '') + (priceOption ? '?price='+priceOption : ''));
// }

export function getStaysByPlaceCode(code, params) {
  return ZAxios.get('stays/places/'+code, {params});
}

export function getViewPointsByPlaceCode(code) { 
  return ZAxios.get('view-point/'+code);
}

export function getStayByStayCode(code) {
  return ZAxios.get('stay/'+code);
}

export function getStayRelatedByPlaceCode(code) {
  return ZAxios.get('stay/related/'+code);
}

export function getPhoneByStayCode(code) {
  return ZAxios.get('stays/phone');
}

export function getPackageByCode(code) {
  return ZAxios.get('package/'+code);
}

export function getPackagesByPlaceCode(code) {
  return ZAxios.get('packages/'+code);
}