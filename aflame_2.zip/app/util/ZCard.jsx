import { Link } from '@remix-run/react';
import React from 'react'
import {Card, Button } from 'react-bootstrap';

function ZCard(props) {
  return (
    <div className='zcard-container'>
      <Link className='d-none' to={props.linkUrl}></Link>
        {props.isRibbon && props.subtitle && <div class="hor-ribbon">{props.subtitle}</div>}
        <Card onClick={props.onClick} style={{ margin: '5px'}}>
        <Card.Img variant="top" className='zcard-img' src={props.imageLink} />
        {!props.isRibbon && props.subtitle &&  <Card.Subtitle>{props.subtitle}</Card.Subtitle>}
        <Card.Body>
          {props.title && <Card.Title>{props.title}</Card.Title>}
          <Card.Footer>
              {props.body}
          </Card.Footer>
          {props.btnLabel && <Button onClick={()=> props.btnAction} variant="primary">{props.btnLabel}</Button>}
        </Card.Body>
      </Card>
    </div>
    
  )
}

export default ZCard