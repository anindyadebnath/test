import { useEffect, useState } from "react";
import { Blurhash } from "react-blurhash";

function BlurredUpImage({src}) {
  
    const [imageLoaded, setImageLoaded] = useState(false);

    useEffect(()=> {
        const img = new Image()
        img.onload = ()=> {
            setImageLoaded(true)
        }
        img.src = src
    }, [src])

  return (
    <>
        <div style={{display: imageLoaded ? 'none' : 'inline'}}>
            <Blurhash
                hash="LEHV6nWB2yk8pyo0adR*.7kCMdnj"
                resolutionX={32}
                resolutionY={32}
                punch={1}
                />
        </div>
        <img
            src={src}
            alt=''
            className='img-fluid w-100'
            style={{display: !imageLoaded ? 'none' : 'inline'}}
        />
    </>
  );
};

export default BlurredUpImage