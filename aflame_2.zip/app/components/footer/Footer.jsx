import React from 'react'
import footerCss from './Footer.css?url'
import { FaWhatsapp } from "react-icons/fa6";
import { MdOutlineMail } from "react-icons/md";
import { MdCopyright } from "react-icons/md";



function Footer() {
  return (
    <div className='footer-con'>
        <div className='row'>
            <div className='col-md-4 footer-con-col col-7'>
                <div className='title'>Tour Packages</div>
                <div>
                  <ul>
                      {/* <li><Link to={'/packages/DH48183'}>Darjeeling package</Link></li> */}
                      <li><a href='/packages/DH48183'>Darjeeling package</a></li>
                      <li>Himachal package</li>
                      <li>Sundarban package</li>
                      <li>Shantiniketan package</li>
                      <li>Purulia package</li>
                  </ul>
                </div>
                
            </div>

            <div className='col-md-4 footer-con-col col-5'>
              <div className='title'>Hotel & Stay</div>
                  <div>
                    <ul>
                        {/* <li><Link to={'/packages/DH48183'}>Darjeeling package</Link></li> */}
                        <li> <a href='/place/DJ8129'>Darjeeling</a></li>
                        <li>Himachal</li>
                        <li>Sundarban</li>
                        <li>Shantiniketan</li>
                        <li>Purulia</li>
                    </ul>
                  </div>
            </div>

            <div className='col-md-4 footer-con-col'>
              <div className='title m-3'>Contact Us</div>
                <div>
                    <FaWhatsapp /> 73617372627
                </div>
                <div>
                    <MdOutlineMail /> contactus.urstays@gmail.com
                </div>
            </div>
        </div>
      
      <div className='copy-right'>
        <MdCopyright /> 2024 urstays.in
      </div>

    </div>
  )
}

export default Footer

export function links() {
  return [
    { rel: "stylesheet", href: footerCss}
  ];
}