import React, { useState } from 'react';
import locSearchbarCss from './LocSearchbar.css?url';
import ZSearchSelect from '../../../util/ZSearchSelect';
import ZSearchMultiSelect from '../../../util/ZSearchMultiSelect';


  const priceOptions = [
    { value: '1000', name: 'Under 1000' },
    { value: '1200', name: 'Under 1200' },
    { value: '1500', name: 'Under 1500' },
    { value: '1700', name: 'Under 1700' }
  ]


  //const isMobile = () => /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

const LocSearchbar = (props) => {

    const [locOption, setLocOption] = useState()
    const [packageLocOption, setPackageLocOption] = useState()
    // const [tagOption, setTagOption] = useState([])
    const [tagsOptions, setTagsOptions] = useState(props.tagsOptions)
    const [priceOption, setPriceOption] = useState()
    const [multiSelectDisp, setMultiSelectDisp] = useState()

    const handleLocChange = (option) => {
        option && setLocOption(option.code);
    };

    const handlePackageLocChange = (option) => {
        option && setPackageLocOption(option.code);
    };
    
    const handleTagsChange = (option) => {
        let el = document.getElementById('tagsDisp')
        let filteredTags = tagsOptions.filter(t=> t.code != option.code)
        filteredTags.push(option)
        setTagsOptions(filteredTags)
        el.innerText = filteredTags.filter(e=> e.checked).map((e)=> e.name).join(" , ")
        let selectedCount = filteredTags.filter(e=> e.checked).length
        setMultiSelectDisp(selectedCount > 0 ? selectedCount + ' selected' : '')
    };

    const handlePriceChange = (option) => {
    option && setPriceOption(option.value);
    };

    
  return (
  <>
    {props.isHotel && <div className='search-container'>
        <div className='selection-block'>
            <div  className='d-flex justify-content-evenly'>
                <div className='location-select-label'>Location:</div>
                <div className=''>
                    <ZSearchSelect
                        options={props.placeOptions} btnId='hotelSearchSelect' btnLabel='location'
                        listClick={handleLocChange}
                        placeHolder="Search..."
                    />
                </div>
            </div>

            <div  className='d-flex justify-content-evenly  mt-3'>
                <div className='price-select-label'>  Price:</div>
                <div className='ms-4'>
                    <ZSearchSelect
                        options={priceOptions} btnId='priceSelect' btnLabel='price'
                        listClick={handlePriceChange}
                        placeHolder="Select..."
                    />
                </div>
            </div>
            
            {props.displayTags && <>
            <div className='col-md-12 offset-md-4 offset-2 d-flex mt-0 tags-con mt-2' ><>&nbsp;</><span id="tagsDisp"></span></div>
            <div  className='d-flex justify-content-evenly'>
                <div className='price-select-label'>Filters:</div>
                    <ZSearchMultiSelect
                            options={tagsOptions} btnId='tagsSearchSelect' btnLabel='tags'
                            listClick={handleTagsChange}
                            value = {multiSelectDisp}
                        />
            </div></>}
        </div>
        
        <div className='mt-1'>
            <button type="button" onClick={()=> locOption && props.onSearchBtn(locOption,priceOption, tagsOptions)} className="searchBtn">Explore</button>
        </div>
    </div>}


    {props.isPackage && <div  className='packageSearchMain'>
        <div className='packageSearchTab'>
            <div className='packageSearchTab-inner'>
                <ZSearchSelect
                    options={props.placeOptions} btnId='packageSearchSelect'
                    listClick={ handlePackageLocChange}
                    placeHolder="Search..."
                />
            </div>
            <div className='package-go' onClick={()=> packageLocOption && props.onGoBtn(packageLocOption)}>Go</div>
        </div>
        
    </div>}
    </>
  )
}

export default LocSearchbar

export function links() {
    return [{rel:'stylesheet', href:locSearchbarCss}]
  }
