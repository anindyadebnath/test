import React, { useEffect } from 'react'
import homePageCss from './HomePage.css?url'
import FavCards, {links as favCardsCss} from './favCards/FavCards';
import TextBanner, {links as textBannerCss} from './textBanner/TextBanner';
import TabSearch, {links as tabSearchCss} from './searchbar/TabSearch';



import { FaArrowRight } from "react-icons/fa";

function HomePage(props) {

  useEffect(()=> {
      let offCanvasCloseBtn = document.getElementsByClassName('btn-close')[0]
      offCanvasCloseBtn && offCanvasCloseBtn.click()
  },[])

  return (
    <div>
        <div  className='banner'>
            {/* <TextBanner/> */}
            
              <div className='d-flex flex-wrap col-12 col-md-12 p-2'>
                <div className='serach-row-box col-md-6 col-12'>
                  <div className='tabs-cont'>
                      <TabSearch/>
                  </div>
                </div>
                <div className='news-main-cont serach-row-box col-md-6 col-12'>
                  <div className='news-cont'>
                      <div className='d-flex justify-content-center f-w-5 mid-text'>
                            Upcoming Tours & Offers
                      </div>
                      <div className='all-list'>
                          <ul className='mt-2'>
                            <li><FaArrowRight/> Manali 5D/4N - Date : 12 Nov 2024 </li>
                            <li><FaArrowRight/> Darjeeling 3D/2N - Date : 21 July 2024</li>
                            <li><FaArrowRight/> North Bengal Offbeat 5D/4N - Date : 15 Sep 2024 </li>
                            <li><FaArrowRight/> Sundarban 3D/2N - Date : 11 Dec 2024</li>
                          </ul>
                      </div>
                      
                  </div>
                </div>
              </div>
          
        </div>
        
        <div>
            <FavCards {...props}/>
        </div>
    </div>
    
  )
}

export function links() {
  return [{rel:'stylesheet', href:homePageCss}, ...favCardsCss(),
     ...tabSearchCss(), ...textBannerCss()]
}

export default HomePage