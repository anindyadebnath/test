import React from 'react';
import './topDestination.css';
import destiPic from '../../../resource/darj.JPG'
import { useNavigate } from 'react-router-dom';


const TopDestination = (props) => {
  const navigate = useNavigate();
  return (
    <div className='dest-card-container'>
        <div onClick={()=> navigate('/place/'+props.destination.code)}>
          <img className='dest-card-banner' src={destiPic}></img>
        </div>
        <div className='dest-card-text-container'>
          <div className='dest-card-text-title'>
               <strong>{props.destination.name}</strong>
          </div>
          
        </div>
    </div>
    
  )
}

export default TopDestination
