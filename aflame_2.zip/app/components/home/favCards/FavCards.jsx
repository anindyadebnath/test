import React, { useEffect, useState } from 'react';
import favCardsCss from './FavCards.css?url';
import ZCard from '../../../util/ZCard';
import { useNavigate } from 'react-router-dom';
import { FaAngleLeft } from "react-icons/fa6";
import { FaAngleRight } from "react-icons/fa6";
import ZImageOverlay, {links as imageOverlayCss} from '../../../util/image-overlay/ZImageOverlay';
import scrollerCss from '../../../styles/scroller.css?url'


export const stayCardBody = (e)=> {
   return (
      <>
         <span className='f-w-5'></span> {e.name} <br/>
         Per night <span className='f-w-5'>Rs. {e.finalPrice}</span> <s>Rs.{e.price}</s> <span className='discount'>{e.discount}% Off</span>
      </>
      
   )}


const FavCards = (props) => {

   const navigate = useNavigate();

   const scrollHor = (side, eleName)=> {
      const el = document.getElementsByClassName(eleName)[0];
      let scrollAmount =0;
      const distance = 350;
      const step =10;
      const speed = 10;

      let slideTimer = setInterval(function() {   
           if(side == 'right') {
               el.scrollLeft += step;
               } else {
               el.scrollLeft -= step;
               }
           scrollAmount += step;
           if(scrollAmount >= distance){
               window.clearInterval(slideTimer);
           }
       }, speed);
       
   }

  
   
   const packageBody = (e)=> {
      return (
         <>
               <span className='f-w-5'>{e.title} </span>| <span className='fsize13'>{e.locationDays}</span>
          </>
      )
   }


  return (
    <div>
         <div>
            <div className='d-flex justify-content-between'>
               <div className='f-w-7 mid-text mt-3 ps-4'>Hotel & Home Stay in Offbeat places</div>
               <div className='mt-3 scroller-btn pe-3'>
                        <button className='' onClick={()=>scrollHor('left', 'stay-cards-hor-con')}><FaAngleLeft/></button>
                        <button onClick={()=>scrollHor('right', 'stay-cards-hor-con')}><FaAngleRight/></button>
               </div>
            </div>
            

            {props.offbeatPlaces && props.offbeatPlaces.length > 0 && <div className='stay-cards-scroll mt-1 py-2'>
               <div className='stay-cards-hor-con'>
                  {props.offbeatPlaces && props.offbeatPlaces.length > 0 && props.offbeatPlaces.sort((e1,e2)=> e2.popularityRate - e1.popularityRate).map((e,i)=> <ZImageOverlay key={i} linkUrl={'/place/'+e.code}  onCardClick={()=> navigate('/place/'+e.code)}
                   thumbnail={e.thumbnail} name={e.name} popularityRate={e.popularityRate}/>)}
               </div>
            </div>}
         </div>






         <hr/>
        {/* <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Weekend trip</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            <div className='stay-cards-container'>
               {props.stays && props.stays.length > 0 && props.stays.map((e,i)=> <ZCard key={i} onClick={()=> navigate('/place/'+ e.locationCode +'/stay/'+e.code)} imageLink={e.thumbnail} body={stayCardBody(e)} subtitle={e.location}/>)}
            </div>
         </div> */}

         <div>
               <div className='hor-center flex-col'>
                  <div className='hor-center font-large'><strong>Weekend trip</strong></div>
                  <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
               </div>
                <div className='d-flex justify-content-between'>
                    <div className='f-w-7 mid-text mt-1'></div>
                    <div className='mt-3 scroller-btn'>
                            <button className='' onClick={()=>scrollHor('left','cards-hor-con')}><FaAngleLeft/></button>
                            <button onClick={()=>scrollHor('right', 'cards-hor-con')}><FaAngleRight/></button>
                    </div>
                </div>

                {props.tourPackages && props.tourPackages.length > 0 && <div className='cards-scroll1 mt-1 py-2'>
                    <div className='cards-hor-con'>
                    {/* {props.stays && props.stays.length > 0 && props.stays.map((e,i)=> <ZCard key={i} onClick={()=> navigate('/place/'+ e.locationCode +'/stay/'+e.code)} imageLink={e.thumbnail} body={stayCardBody(e)} subtitle={e.location}/>)} */}
                    {props.tourPackages && props.tourPackages.length > 0 && props.tourPackages.filter(t=> t.weekendTrip).map((e,i)=> <ZCard key={i} imageLink={e.imageLink} body={packageBody(e)} 
                     onClick={()=> navigate('/tour-package/details/'+e.code)}
                     linkUrl = {'/tour-package/details/'+e.code}
                     isRibbon ={true}
                     subtitle={<span>Starting Rs.{e.price}</span>}/>)}
                    </div>
                </div>}

            </div>
         
         <hr/>
         <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Explore India</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            <div className='stay-cards-container'>
               {props.tourPackages && props.tourPackages.length > 0 && props.tourPackages.filter(t=> !t.weekendTrip).map((e,i)=> <ZCard key={i} imageLink={e.imageLink} body={packageBody(e)} 
               onClick={()=> navigate('tour-package/details/'+e.code)}
               linkUrl = {'/tour-package/details/'+e.code}
               subtitle={<span>Rs.{e.price} - {e.duration}</span>}/>)}
            </div>
         </div>
    </div>
    
  )
}

export default FavCards

export function links() {
   return [{rel:'stylesheet', href:favCardsCss}, {rel:'stylesheet', href:scrollerCss}, ...imageOverlayCss()]
 }


