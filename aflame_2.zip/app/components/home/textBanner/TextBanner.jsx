import React from 'react';
import textBannerCss from './TextBanner.css?url';

const TextBanner = () => {
  return (
    <div className='hor-center banner-text'>
            Zero Commission on bookings. Direct booking with Owner.
    </div>
  )
}

export default TextBanner

export function links() {
  return [{rel:'stylesheet', href:textBannerCss}]
}
