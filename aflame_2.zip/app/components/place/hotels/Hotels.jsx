import React, { useEffect, useState } from 'react'
import Hotel, {links as hotelCss} from './hotel/Hotel'
import hotelsCss from './Hotels.css?url';
import { FiFilter } from "react-icons/fi";
import { useNavigate } from 'react-router-dom';
import LocSearchbar, {links as locSearchbarCss} from '../../home/searchbar/LocSearchbar';
import ZModal from '../../../util/ZModal';
import { tagsOptions } from '../../../util/DataUtil';
import { useRouteLoaderData } from '@remix-run/react';
import { useLocation } from 'react-router-dom';

function Hotels(props) {
    const [currPage, updateCurrPage] = useState(1)
    const [filterModalShow, setFilterModalShow] = useState(false)
    const navigate = useNavigate()

    const rootPlaceOptions = useRouteLoaderData('root')
    const location = useLocation()
    


    useEffect(()=> {
        setFilterModalShow(false)
        Object.values(tagsOptions).map(t=> {t.checked = false; return t})
    },[location])


    const onSearchBtn = (locOption,priceOption,tagOption) => {
        let params = new Array()
        let tags = Object.values(tagOption).filter(t=> t.checked).map(t=> t.code).join(',') 
        let path = '/place/'+locOption+'?'
        priceOption && params.push('price='+priceOption)
        tags && params.push('tags='+tags)
        path = path + params.join('&')
        navigate(path)
      }

    const callPageWith = (pageNum)=> {
        updateCurrPage(pageNum)
    }

    const totalPage = props.stayCards.length/3;

    const filterBody = (
        <div className='col-xl-12 col-lg-12 col-md-12 col-sm-12 row'>
            <LocSearchbar tagsOptions={Object.values(tagsOptions)} 
            placeOptions={Object.values(rootPlaceOptions)}
            onSearchBtn = {onSearchBtn}
            displayTags={true}
            isHotel={true}/>
        </div>
            
        
    )

    const paginationUI = (
        <div className='col-xl-10 col-lg-10 col-md-9 col-sm-9 col-8 justify-content-end mt-2 d-flex'>
        <nav id='loc-pagination'  aria-label="location pagination">
            <ul class="pagination">
                <li className= {1 == currPage ? 'page-item disabled' : 'page-item'}>
                <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
                </li>
                {new Array(Math.ceil(totalPage)).fill(0).map((e,i)=> {
                    return <li class= {i+1 == currPage ? 'page-item active' : 'page-item'} onClick={()=> callPageWith(i+1)}><a class="page-link" href="javascript:void(0)">{i+1}</a></li>
                })}
                <li className= {Math.ceil(totalPage) == currPage ? 'page-item disabled' : 'page-item'}>
                <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
                </li>
            </ul>
        </nav>
        </div>
    )

    const filter = (
        <div className='col-xl-2 col-lg-2 col-md-3 col-sm-3 col-4 row'>
            <span className='filter' onClick={()=> setFilterModalShow(true)}><FiFilter/> <strong>Filter</strong></span>
        </div>
        
    )

  return (
    <div className='hotels-container'>
        {<ZModal
            class='hotel-search-modal'
            size='lg'
            title='Search and Explore more'
            show={filterModalShow}
            body={filterBody}
            onHide={() => setFilterModalShow(false)}/>}

        {props.stayCards && props.stayCards.length>0 && <div className='hotels-list'>
            <div className='loc-page col-xl-12 col-lg-12 col-md-12 col-sm-12 row'>
                {filter}
                {totalPage > 1 && paginationUI}
            </div>
            
            {Object.values(props.stayCards).map((s,i)=> {
                return <Hotel key={i} stay={s}/>
            })}
           <div className='loc-page col-xl-12 col-lg-12 col-md-12 col-sm-12 row'>
                {filter}
                {totalPage > 1 && paginationUI}
            </div>
        </div>}
        {(!props.stayCards || props.stayCards.length == 0) && <div className='zero-hotels container'>
            Sorry No Hotel / Stay found. Please modify the filter and search again...
            {/* {<ZModal
            class='hotel-search-modal'
            size='lg'
            title='Search and Explore more'
            show={filterModalShow}
            body={filterBody}/>} */}
            <div><button className='searchBtn' onClick={()=> setFilterModalShow(true)}>Search</button></div>
        </div>}
    </div>
  )
}

export default Hotels

export function links() {
    return [{ rel: "stylesheet", href: hotelsCss}, ...hotelCss(), ...locSearchbarCss()];
  }