import { PiAirplaneTiltLight } from "react-icons/pi";
import { LuBedDouble } from "react-icons/lu";
import { TbPlaneTilt } from "react-icons/tb";
import { BsBinoculars } from "react-icons/bs";
import { GiHotMeal } from "react-icons/gi";
import { LiaCarSideSolid } from "react-icons/lia";
import itineraryCss from './Itinerary.css?url'


function Itinerary() {
    return (
        <>
            <div className="itinerary-icons">
                <div className="stroke-1">
                    <TbPlaneTilt /> <br/> Flight
                </div>
                <div className="stroke-1">
                    <LuBedDouble /> <br/> Hotel
                </div>
                <div>
                    <BsBinoculars className="ms-3"/> <br/>Sightseeing
                </div>
                <div>
                    <GiHotMeal /> <br/> Meals
                </div>
                <div>
                    <LiaCarSideSolid /> <br/> Transfer
                </div>
            </div>
        </>
    )
}

export function links() {
    return [{rel:'stylesheet', href:itineraryCss}]
  }

export default Itinerary