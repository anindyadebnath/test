import React, { useEffect } from 'react'
import ZCard from '../../util/ZCard'
import { useNavigate } from 'react-router-dom'
import tourPackagesCss from './TourPackages.css?url'
import { MdOutlineDashboardCustomize } from "react-icons/md";
import { FaRegHandPointRight } from "react-icons/fa";
import {links as favCardsCss } from "../home/favCards/FavCards"



const packages = [
    {
        "title" : "Exotic Himachal with Amritsar",
        "thumbnail" : "https://images.pexels.com/photos/1928491/pexels-photo-1928491.jpeg",
        "shortDuration" : "5N/6D",
        "locationDays" : "2N Dharamshala - 2N Dalhousie - 1N Amritsar",
        "inclusions" : ["Intercity Car Transfers","3 Star Hotels","Airport Pickup & Drop","Selected Meals"],
        "code": "P6728",
        "isCustomized" : false,
        "isScheduled" : false,
        "price" : 1234,
        "visits" : ["Visit to Mall road, Scandal Point, Viceregal Lodge", "Visit to Kufri, Himalayan Nature Park, Naldehra", "Visit to Mall road, Scandal Point, Viceregal Lodge"],
        "tags": [],
        "placeCodes": []
    },
    {
        "title" : "Exotic Himachal with Amritsar",
        "thumbnail" : "https://images.pexels.com/photos/1928491/pexels-photo-1928491.jpeg",
        "shortDuration" : "5N/6D",
        "locationDays" : "2N Dharamshala - 2N Dalhousie - 1N Amritsar - 2N Dharamshala - 2N Dalhousie - 1N Amritsar",
        "inclusions" : ["Intercity Car Transfers","3 Star Hotels","Airport Pickup & Drop","Selected Meals"],
        "code": "P6723",
        "isCustomized" : false,
        "isScheduled" : false,
        "price" : 1234,
        "visits" : ["Visit to Mall road, Scandal Point, Viceregal Lodge", "Visit to Kufri, Himalayan Nature Park, Naldehra", "Visit to Mall road, Scandal Point, Viceregal Lodge"],
        "tags": [],
        "placeCodes": []
    },
    {
        "title" : "Exotic Himachal with Amritsar",
        "thumbnail" : "https://images.pexels.com/photos/1928491/pexels-photo-1928491.jpeg",
        "shortDuration" : "5N/6D",
        "locationDays" : "2N Dharamshala - 2N Dalhousie - 1N Amritsar - 2N Dharamshala - 2N Dalhousie - 1N Amritsar",
        "inclusions" : ["Intercity Car Transfers","3 Star Hotels","Airport Pickup & Drop","Selected Meals"],
        "code": "P3782",
        "isCustomized" : false,
        "isScheduled" : false,
        "price" : 1234,
        "visits" : ["Visit to Mall road, Scandal Point, Viceregal Lodge", "Visit to Kufri, Himalayan Nature Park, Naldehra", "Visit to Mall road, Scandal Point, Viceregal Lodge"],
        "tags": [],
        "placeCodes": []
    },
    {
        "title" : "Exotic Himachal with Amritsar",
        "thumbnail" : "https://images.pexels.com/photos/1928491/pexels-photo-1928491.jpeg",
        "shortDuration" : "5N/6D",
        "locationDays" : "2N Dharamshala - 2N Dalhousie - 1N Amritsar - 2N Dharamshala - 2N Dalhousie - 1N Amritsar",
        "inclusions" : ["Intercity Car Transfers","3 Star Hotels","Airport Pickup & Drop","Selected Meals"],
        "code": "P4624",
        "isCustomized" : false,
        "isScheduled" : false,
        "price" : 1234,
        "visits" : ["Visit to Mall road, Scandal Point, Viceregal Lodge", "Visit to Kufri, Himalayan Nature Park, Naldehra", "Visit to Mall road, Scandal Point, Viceregal Lodge"],
        "tags": [],
        "placeCodes": []
    }
]

export const packageCardBody = (e)=> {
    return (
       <>
            <div className=''>
                <span className=' f-w-5 mid-text'>{e.title}</span><br/>
                {e.customisable && <span className='shortDuration'> <MdOutlineDashboardCustomize/>Customizable</span>}
                <span className='shortDuration'>{e.shortDuration}</span>
            </div>
            <div className='mt-3'>
                <div className='locationDays'>
                    {e.locationDays}
                </div>
                {/* <div className='mt-2'><span className='shortDuration'> <MdOutlineDashboardCustomize/>Customizable</span></div> */}
            </div >
            
            <hr style={{backgroundColor:'red', color:'red'}}/>
            <div>
                <ul className='inclusion-box'>
                    {Object.values(e.shortInclusion).map((e,i)=> {
                        return <li key={i}>{e}</li>
                    })}
                </ul>  
            </div>
            <div>
                <ul className='visits'>
                    {Object.values(e.shortVisits).map((e,i)=> {
                        return <li key={i}><FaRegHandPointRight/> {e}</li>
                    })}
                </ul>
            </div>
            <div className='packagePriceText  mb-2'>Price starting from <span style={{color:'black'}} className='f-w-5 ms-1'> Rs. {e.price}</span>/person</div>
       </>
    )}


function TourPackages(props) {

    const navigate = useNavigate()
    
    useEffect(()=> {
        let offCanvasCloseBtn = document.getElementsByClassName('btn-close')[0]
        offCanvasCloseBtn && offCanvasCloseBtn.click()
    },[])

  return (
    <div className='row container'>
        <div className='package-list-head mt-3'>
            <div className='head'>Himachal Tour Packages</div>
            <div>
                Due to the captivating splendor and immaculate natural beauty, Shimla was declared by the British as their summer capital. On your Shimla vacation, you can see the evident colonial influence in each aspect of the city. The hill station enjoys panoramic views of the snowcapped Himalayan ranges and offers an array of sightseeing options to explore. Shimla tour packages are sold in great range and one comes to explore here natural beauty.
            </div>
        </div>
        <div className='mt-4 mb-4'>
            <div id='packages-list'>
            <div className='stay-cards-container'>
                {props.packagesData && props.packagesData.length > 0 && props.packagesData.map((e,i)=> <ZCard key={i} onClick={()=> navigate('/tour-package/details/'+ e.code +'?destination='+props.destination)} imageLink={e.thumbnail} body={packageCardBody(e)} />)}
                </div>
            </div>
        </div>
    </div>
    
    
  )
}

export default TourPackages

export function links() {
    return [{ rel: "stylesheet", href: tourPackagesCss}];
  }