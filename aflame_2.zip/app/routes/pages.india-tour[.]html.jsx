export const loader = async () => {

  const htmlCon = `<!DOCTYPE html>
      <html>
      <body>

      <h1>My First Heading</h1>
      <p>My first paragraph.</p>

      </body>
      </html>
  `


    try {
      return new Response(htmlCon, {
        status: 200,
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'X-Content-Type-Options': 'nosniff',
          'Cache-Control': 'public, max-age=3600',
        },
      })
    } catch (e) {
      throw new Response('Internal Server Error', { status: 500 })
    }
  }