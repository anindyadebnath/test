import { json, useLoaderData, useNavigation, useParams } from "@remix-run/react";
import TourPackages, {links as tourPackagesCss} from "../components/tour-packages/TourPackages";
import { getPackagesByPlaceCode } from "../util/ZAxios";
import GrowRowSpinner from "../util/GrowRowSpinner";

export const meta = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function PackagesRoute() {

  const packagesData = useLoaderData()
  const { state } = useNavigation();

  let { destination } = useParams();
  
  if (state === "loading") {
    return <GrowRowSpinner/>
  }
  
  return (
    <TourPackages
    packagesData = {Object.values(packagesData)}
    destination = {destination}
    />
  );
}

export function links() {
  return [...tourPackagesCss()]
}

export async function loader({params,request}) {
  const res = await getPackagesByPlaceCode(params.destination)
  return json(res.data)
}
