import { json, useLoaderData, useNavigation } from "@remix-run/react";
import { getStayByStayCode } from "../util/ZAxios";
import Stay, {links as stayCss} from "../components/stay/Stay";
import GrowRowSpinner from "../util/GrowRowSpinner";

export const meta = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function PlaceStaysRoute() {

  const stayData = useLoaderData();
  const { state } = useNavigation();
  
  if (state === "loading") {
    return <GrowRowSpinner/>
  }
  
  return (
    <Stay 
    stayData={stayData}
    />
  );
}

export async function loader({params,request}) {

  const stayRes = await getStayByStayCode(params.code)
  return json(stayRes.data)
}

export function links() {
  return [...stayCss()]
}