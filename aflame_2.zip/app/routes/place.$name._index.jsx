import { json, useLoaderData, useNavigation } from "@remix-run/react";
import {getStaysByPlaceCode, getViewPointsByPlaceCode } from "../util/ZAxios";
import Place, {links as placeCss} from "../components/place/Place";
import { useEffect } from "react";
import GrowRowSpinner from "../util/GrowRowSpinner";

export const meta = ({params}) => {
  return [
    { title: 'Hotel & Stay | ' + params.name + ' | Direct booking & enquiry homestay | tripbite.in'},
    { name: 'description', content: 'North bengal homestay and hotel booking. Choose your stay from our varity of collection from ' + params.name},
    {name:'keywords', content: 'homostay, north bengal, short trip, tripbite, best homestay, best place'}
  ];
};

export default function PlaceRoute() {

  let {stays,viewPoint} = useLoaderData();

  useEffect(()=> {
    let offCanvasCloseBtn = document.getElementsByClassName('btn-close')[0]
    offCanvasCloseBtn && offCanvasCloseBtn.click()
},[])
  
const { state } = useNavigation();
  
  if (state === "loading") {
    return <GrowRowSpinner/>
  }
  return (
    <Place 
    stays={stays}
    viewPoint={viewPoint}
    />
  );
}

export async function loader({params, request}) {
  
  const url = new URL(request.url)

  const priceOption = url.searchParams.get('price')
  const tagOption = url.searchParams.get('tags')

  const reqparams = new URLSearchParams(); 
  if(priceOption) {
    reqparams.append(`price`,priceOption)
  }
  if(tagOption) {
    reqparams.append(`tags`,tagOption)
  }
  const staysRes = await getStaysByPlaceCode(params.name, reqparams)
  const viewpointsRes = await  getViewPointsByPlaceCode(params.name)

  return json(
    {
      stays: staysRes.data,
      viewPoint: viewpointsRes.data
    }
  )
}

export function links() {
  return [...placeCss()]
}