import { json, useLoaderData, useNavigation, useRouteLoaderData } from "@remix-run/react";
import HomePage, {links as homePageCss} from "../components/home/HomePage";
import GrowRowSpinner from "../util/GrowRowSpinner";
import { getHomePageTourPackageCard } from "../util/ZAxios";

export const meta = () => {
  return [
    { title: "Tripbite | Homestay Booking & Tour packages" },
    { name: "description", content: `Explore North bengal offbeat destination.
       Connect directly with Homestay owner and book your favourite homestay.
       Explore our tour packages and experience a hasle free journey.` },
    {name:'keywords', content: 'homostay, north bengal, tour package, holiday package, weekend trip, short trip, tripbite, cheap package, best tour package'}
  ];
};

export default function Index() {

  let {tourPackages,stays} = useLoaderData();
  const places = useRouteLoaderData("root");
  const { state } = useNavigation();
  
  if (state === "loading") {
    return <GrowRowSpinner/>
  }
  
  return (
    <HomePage
    tourPackages={tourPackages}
    places={places}
    offbeatPlaces = {places.filter(p=> p.offbeat && p.parentLoc.includes('darjeeling'))}
    />
  );
}

export async function loader() {
  
  const promoPackage = await  getHomePageTourPackageCard()

  return json(
    {
      tourPackages: promoPackage.data,
    }
  )
}

export function links() {
  return [...homePageCss()];
}