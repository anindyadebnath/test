import { json, useLoaderData, useNavigation } from "@remix-run/react";
import PackageDetails, {links as packageDetailsCss} from "../components/package-util/z-timeLine/PackageDetails";
import { getPackageByCode } from "../util/ZAxios";
import GrowRowSpinner from "../util/GrowRowSpinner";

export const meta = () => {
  return [
    { title: "Tour package | Best deal of packages | tripbite.in" },
    { name: "description", content: "" },
  ];
};

export default function PackageDetailsRoute() {

  const {packageData, destination} = useLoaderData()
  const { state } = useNavigation();
  
  if (state === "loading") {
    return <GrowRowSpinner/>
  }
  
  return (
    <PackageDetails
      packageData = {packageData.tourPackageDto}
      otherPackages = {packageData.homePagePackageCard}
      destination = {destination}
    />
  );
}

export function links() {
  return [...packageDetailsCss()]
}

export async function loader({params,request}) {
  const url = new URL(request.url)
  const destination = url.searchParams.get('destination')

  const res = await getPackageByCode(params.code)
  //return json(res.data)

  return json(
    {
      packageData: res.data,
      destination : destination ? destination : ''
    }
  )
}
