package com.zupalo.flamingo.controller;

import com.zupalo.flamingo.dto.StayDto;
import com.zupalo.flamingo.dto.TopStayCard;
import com.zupalo.flamingo.mapper.DtoMapper;
import com.zupalo.flamingo.model.PromoteStay;
import com.zupalo.flamingo.model.Stay;
import com.zupalo.flamingo.model.TourPackage;
import com.zupalo.flamingo.repository.PromoteStaysRepository;
import com.zupalo.flamingo.repository.StayRepository;
import com.zupalo.flamingo.repository.TourPackageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;


@CrossOrigin(origins = "*", methods = {RequestMethod.GET})
@RestController()
public class StayController {

    @Autowired
    private StayRepository stayRepository;


    @Autowired
    private PromoteStaysRepository promoteStaysRepository;

    @Autowired
    private DtoMapper dtoMapper;

    @GetMapping("stays")
    public ResponseEntity<List<Stay>> getAllStays(){
        return ResponseEntity.ok().body(stayRepository.findAll());
    }

    @GetMapping("stays/phone")
    public ResponseEntity<String> getPhone() throws InterruptedException {
        return ResponseEntity.ok().body("7654321123");
    }

    @GetMapping("stays/top/card")
    public ResponseEntity<List<TopStayCard>> getTopStaysCard() {
        List<PromoteStay> promoteStays= promoteStaysRepository.findAll();
        List<String> promoteStaysCode = promoteStays.stream().filter(e-> e.isPromoted()).map(e-> e.getCode()).toList();
        List<Stay> stays = stayRepository.findByCodeIn(promoteStaysCode);

        return ResponseEntity.ok().body(dtoMapper.mapStayToTopStayCard(stays));
    }

    @GetMapping("stay/related/{placeCode}")
    public ResponseEntity<List<TopStayCard>> getRelatedStaysCardByPlaceCode(@PathVariable String placeCode) throws InterruptedException {
        List<PromoteStay> promoteStays= promoteStaysRepository.findAll();
        List<String> promoteStaysCode = promoteStays.stream().filter(e-> e.isPromoted()).map(e-> e.getCode()).toList();
        Set<String> promoteStaysCodeSets = promoteStaysCode.stream().collect(Collectors.toSet());
        List<Stay> stays = stayRepository.findByCodeIn(promoteStaysCode);
        stays = stays.stream().filter(s-> s.getDestination().getCode().equalsIgnoreCase(placeCode)).toList();

        return ResponseEntity.ok().body(dtoMapper.mapStayToTopStayCard(stays));
    }

    /*@GetMapping("stays/places/{code}")
    public ResponseEntity<List<Stay>> getStaysByPlaceCode(@PathVariable("code") String code) throws InterruptedException {
        Thread.sleep(5000);
        return ResponseEntity.ok().body(stayRepository.findByDestinationCode(code));
    }*/

    @GetMapping("stays/places/{code}")
    public ResponseEntity<List<TopStayCard>> getStaysByPlaceCode(@PathVariable("code") String code, @RequestParam(value = "price", required = false) String price,
                                                                 @RequestParam(value = "tags", required = false) String tags) {
        int priceLimit = Integer.MAX_VALUE;
        try {
            if(price != null && !price.isEmpty()) {
                priceLimit = Integer.parseInt(price);
            }
        } catch (Exception e) {

        }
        int finalPriceLimit = priceLimit;
        List<String> tagList = Optional.ofNullable(tags).map(s-> Arrays.stream(s.split(",")).toList()).orElse(new ArrayList<>());
        List<Stay> allStays;
        if(tagList.isEmpty()) {
            allStays = stayRepository.findByDestinationCode(code).stream().filter(s-> s.getPrice() <= finalPriceLimit).toList();
        } else {
            allStays = stayRepository.findByDestinationCodeAndTags(code,tagList).stream().filter(s -> s.getPrice() <= finalPriceLimit).toList();
        }
        return ResponseEntity.ok().body(dtoMapper.mapStayToTopStayCard(allStays));
    }

    @GetMapping("stay/{code}")
    public ResponseEntity<StayDto> getStaysByCode(@PathVariable("code") String code) throws InterruptedException {
        Stay stay = stayRepository.findByCode(code);
        List<TopStayCard> relatedStayCards = getRelatedStaysCardByPlaceCode(stay.getDestination().getCode()).getBody();
        relatedStayCards.addAll(relatedStayCards);
        StayDto dto = StayDto.builder().stay(stay).relatedStays(relatedStayCards).build();
        return ResponseEntity.ok().body(dto);
    }
}
