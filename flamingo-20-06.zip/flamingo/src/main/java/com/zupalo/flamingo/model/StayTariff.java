package com.zupalo.flamingo.model;

import lombok.Data;

@Data
public class StayTariff {
    private String title;
    private String priceDesc;
    private String desc;
}
