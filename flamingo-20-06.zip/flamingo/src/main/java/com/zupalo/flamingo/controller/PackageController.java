package com.zupalo.flamingo.controller;


import com.zupalo.flamingo.dto.HomePagePackageCard;
import com.zupalo.flamingo.dto.PackagesByPlaceCodeCard;
import com.zupalo.flamingo.dto.TourPackageDto;
import com.zupalo.flamingo.dto.TourPackageWithCardsDto;
import com.zupalo.flamingo.mapper.DtoMapper;
import com.zupalo.flamingo.model.TourPackage;
import com.zupalo.flamingo.model.ViewPoint;
import com.zupalo.flamingo.repository.TourPackageRepository;
import com.zupalo.flamingo.repository.ViewPointRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET})
@RestController()
public class PackageController {

    @Autowired
    private TourPackageRepository packageRepository;

    @Autowired
    private DtoMapper dtoMapper;

    @GetMapping("packages/promoted/card")
    public ResponseEntity<List<HomePagePackageCard>> getHomePagePromotedPackageCards() {
        List<HomePagePackageCard> list = dtoMapper.mapPackageToHomePromotedCard(packageRepository.getPromotedPackage(true));
        list.addAll(list);list.addAll(list);list.addAll(list);
        return ResponseEntity.ok().body(list);
    }

    @GetMapping("package/{code}")
    public ResponseEntity<TourPackageWithCardsDto> getPackageDetailsWithCards(@PathVariable("code") String code) {
        TourPackageDto dto  = dtoMapper.mapDBPackageToPackageDetails(packageRepository.getTourPackageByCode(code));
        List<HomePagePackageCard> list = dtoMapper.mapPackageToHomePromotedCard(packageRepository.getTourPackageByPlaceCodes(dto.getPlaceCodes()));
        list.addAll(list);list.addAll(list);list.addAll(list);
        TourPackageWithCardsDto tourPackageWithCardsDto = TourPackageWithCardsDto.builder()
                .tourPackageDto(dto)
                .homePagePackageCard(list)
                .build();

        return ResponseEntity.ok().body(tourPackageWithCardsDto);
    }

    @GetMapping("packages/{code}")
    public ResponseEntity<List<PackagesByPlaceCodeCard>> getPackagesByPlaceCode(@PathVariable("code") String code) {
        List<PackagesByPlaceCodeCard> list = dtoMapper.mapTourPackageToPackagesByPlaceCode(packageRepository.getTourPackageByPlaceCodes(List.of(code)));
        list.addAll(list);list.addAll(list);list.addAll(list);

        return ResponseEntity.ok().body(list);
    }
}
