package com.zupalo.flamingo.repository;

import com.zupalo.flamingo.model.Stay;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StayRepository extends MongoRepository<Stay, String> {

    @Query(value = "{'destination.code':?0}")
    List<Stay> findByDestinationCode(String code);

    @Query(value = "{'$and':[{'destination.code':?0} , {tags: {$in: ?1} }]}")
    List<Stay> findByDestinationCodeAndTags(String code, List<String> tags);

    List<Stay> findByCodeIn(List<String> codes);

    Stay findByCode(String code);



}
