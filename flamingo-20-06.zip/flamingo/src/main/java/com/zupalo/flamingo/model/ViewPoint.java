package com.zupalo.flamingo.model;


import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("view-points")
@Data
public class ViewPoint {

    private String placeCode;
    private String placeName;
    private ViewPointImages[] images;
}

@Data
class ViewPointImages {
    private String imgLink;
    private String title;
    private String desc;
}
