package com.zupalo.flamingo.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("places")
@Data
public class Destination {
    private String code;
    private String name;
    private String thumbnail;
    private String business;
}
