package com.zupalo.flamingo.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class StaticData {

    public static Map<Integer,String> inclusions = Map.ofEntries(
            Map.entry(1,"Intercity Car Transfers"),
            Map.entry(2,"3 Star Hotels"),
            Map.entry(3,"Pick up and drop from nearest Airport/Rail Station"),
            Map.entry(4,"Selected Meals"),
            Map.entry(5,"Night accommodation"),
            Map.entry(6,"All tours and transfers by Private NON-AC sedan vehicle"),
            Map.entry(7,"All major attractions and local sight-seeing"),
            Map.entry(8,"All toll tax parking charges, driver allowance etc")
    );

    public static Map<Integer,String> exclusions = Map.ofEntries(
            Map.entry(1,"Upgrade to hotel/room category"),
            Map.entry(2,"All meals"),
            Map.entry(3,"Heaters"),
            Map.entry(4,"Camera fees"),
            Map.entry(5,"Airfare/train fares"),
            Map.entry(6,"Travel insurance"),
            Map.entry(7,"Laundry/telephone bills/shopping/personal expenditure"),
            Map.entry(8,"Optional sight seeing/Cab other than what is covered"),
            Map.entry(9,"Adventure activities")
    );

    public static List<String> getInclusions(Integer[] nums) {
        List<String> list = new ArrayList<>();
        for(int i :nums) {
            list.add(inclusions.get(i));
        }
        return list;
    }

    public static List<String> getExclusions(Integer[] nums) {
        List<String> list = new ArrayList<>();
        for(int i :nums) {
            list.add(exclusions.get(i));
        }
        return list;
    }
}
