package com.zupalo.flamingo.mapper;


import com.zupalo.flamingo.dto.HomePagePackageCard;
import com.zupalo.flamingo.dto.PackagesByPlaceCodeCard;
import com.zupalo.flamingo.dto.TopStayCard;
import com.zupalo.flamingo.dto.TourPackageDto;
import com.zupalo.flamingo.model.Stay;
import com.zupalo.flamingo.model.TourPackage;
import com.zupalo.flamingo.repository.StaticData;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class DtoMapper {

   public List<TopStayCard> mapStayToTopStayCard(List<Stay> stays) {
        List<TopStayCard> list = new ArrayList<>();
        stays.forEach(s-> {
            TopStayCard topStay = TopStayCard.builder()
                    .code(s.getCode())
                    .name(s.getName())
                    .shortDesc(s.getShortDesc())
                    .locHelp(s.getLocHelp())
                    .thumbnail(s.getThumbnail())
                    .amenities(s.getAmenities())
                    .location(s.getDestination().getName())
                    .locationCode(s.getDestination().getCode())
                    .discount(s.getDiscount())
                    .price(s.getDiscount())
                    .finalPrice(s.getPrice() * (100 - s.getDiscount())/100)
                    .images(Arrays.asList(s.getImages()))
                    .build();

            list.add(topStay);
        });
        return list;
    }

    public List<HomePagePackageCard> mapPackageToHomePromotedCard (List<TourPackage> packages) {
       List<HomePagePackageCard> list = new ArrayList<>();
        packages.forEach(p-> {
            HomePagePackageCard card = HomePagePackageCard.builder()
                    .price(p.getPrice())
                    .imageLink(p.getThumbnailImage())
                    .duration(p.getShortDuration())
                    .code(p.getCode())
                    .title(p.getTitle())
                    .locationDays(p.getLocationDays()).build();
            list.add(card);
        });
        return list;
    }

    public TourPackageDto mapDBPackageToPackageDetails (TourPackage tourPackage) {
       return TourPackageDto.builder()
               .title(tourPackage.getTitle())
               .locationDays(tourPackage.getLocationDays())
               .price(tourPackage.getPrice())
               .code(tourPackage.getCode())
               .titleWithDays(tourPackage.getTitleWithDays())
               .shortDuration(tourPackage.getShortDuration())
               .duration(tourPackage.getDuration())
               .isCustomisable(tourPackage.isCustomisable())
               .isScheduled(tourPackage.isScheduled())
               .images(Arrays.asList(tourPackage.getImages()))
               .inclusion(StaticData.getInclusions(tourPackage.getInclusion()))
               .exclusion(StaticData.getExclusions(tourPackage.getExclusion()))
               .upcomingTourDates(tourPackage.getUpcomingTourDates())
               .provider(tourPackage.getProvider())
               .contact(tourPackage.getContact())
               .placeCodes(Arrays.asList(tourPackage.getPlaceCodes()))
               .itinerary(Arrays.asList(tourPackage.getItinerary()))
               .build();
    }

    public List<PackagesByPlaceCodeCard> mapTourPackageToPackagesByPlaceCode(List<TourPackage> tourPackages) {
        List<PackagesByPlaceCodeCard> list = new ArrayList<>();
        tourPackages.forEach(tp-> {
            PackagesByPlaceCodeCard card = PackagesByPlaceCodeCard.builder()
                    .thumbnail(tp.getThumbnailImage())
                    .shortDuration(tp.getShortDuration())
                    .code(tp.getCode())
                    .price(tp.getPrice())
                    .title(tp.getTitle())
                    .locationDays(tp.getLocationDays())
                    .shortInclusion(StaticData.getInclusions(tp.getShortInclusion()))
                    .shortVisits(Arrays.asList(tp.getShortVisits()))
                    .isCustomisable(tp.isCustomisable())
                    .build();
            list.add(card);
        });
        return list;
    }
}
