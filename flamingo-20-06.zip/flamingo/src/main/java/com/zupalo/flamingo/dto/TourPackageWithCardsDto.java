package com.zupalo.flamingo.dto;


import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class TourPackageWithCardsDto {
    private TourPackageDto tourPackageDto;
    private List<HomePagePackageCard> homePagePackageCard;
}
