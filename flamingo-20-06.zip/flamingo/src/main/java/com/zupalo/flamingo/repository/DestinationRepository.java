package com.zupalo.flamingo.repository;

import com.zupalo.flamingo.model.Destination;
import com.zupalo.flamingo.model.Stay;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DestinationRepository extends MongoRepository<Destination, String> {
}
