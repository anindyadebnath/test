package com.zupalo.flamingo.model;

import lombok.Data;

@Data
public class PackageItinerary {
    private String day;
    private String planTitle;
    private String nightStay;
    private String content;
}
