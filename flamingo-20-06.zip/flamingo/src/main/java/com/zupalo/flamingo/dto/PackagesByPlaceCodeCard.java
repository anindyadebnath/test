package com.zupalo.flamingo.dto;


import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PackagesByPlaceCodeCard {

    private String thumbnail;
    private String shortDuration;
    private String code;
    private int price;
    private String title;
    private String locationDays;
    private List<String> shortInclusion;
    private List<String> shortVisits;
    private boolean isCustomisable;
}
