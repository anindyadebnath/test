package com.zupalo.flamingo.repository;

import com.zupalo.flamingo.model.ViewPoint;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ViewPointRepository extends MongoRepository<ViewPoint, String> {

    ViewPoint findByPlaceCode(String placeCode);
}
