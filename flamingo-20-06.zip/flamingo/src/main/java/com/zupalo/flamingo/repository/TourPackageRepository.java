package com.zupalo.flamingo.repository;

import com.zupalo.flamingo.model.TourPackage;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TourPackageRepository extends MongoRepository<TourPackage, String> {

    @Query(value = "{'isPromoted':?0}")
    List<TourPackage> getPromotedPackage(boolean isPromoted);

    @Query(value = "{'code':?0}")
    TourPackage getTourPackageByCode(String code);

    @Query(value = "{placeCodes: {$in: ?0} }")
    List<TourPackage> getTourPackageByPlaceCodes(List<String> codes);
}
