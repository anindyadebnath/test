import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import { Xnavbar } from './components/navbar/Xnavbar';
import Searchbar from './components/searchbar/Searchbar';
import FavCards from './components/favCards/FavCards';
import OfferBanner from './components/offers/OfferBanner';
import TextBanner from './components/textBanner/TextBanner';

function App() {
  return (
    <div className="App">
      <div  className='banner'>
        <Xnavbar/>
        <TextBanner/>
          <div className='search-offer-container'>
            <Searchbar/>
            <OfferBanner/>
          </div>
      </div>
        <div>
          <FavCards/>
        </div>
    </div>
  );
}

export default App;
