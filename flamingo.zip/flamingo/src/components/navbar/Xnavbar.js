import React from 'react';
import './Xnavbar.css';
import { FaUser,FaHome  } from "react-icons/fa";
import { MdAddBusiness } from "react-icons/md";
import { FiLogIn } from "react-icons/fi";
import { TbPackages } from "react-icons/tb";
import { BsSearchHeart } from "react-icons/bs";
import logo from '../../resource/app-logo.JPG'


export const Xnavbar = ()=> {
  return (
    <div>
      <div className='nav-container'>
        <div className='nav-logo'><img className='logo-image' src={logo} alt="logo"/></div>
        <div className='nav-links'>
          <div className='nav-link-grp'><MdAddBusiness  className='userIcon'/> <div className='nav-link'>List your business</div></div>
          <div className='nav-link-grp'><BsSearchHeart className='userIcon'/> <div className='nav-link'>Popular destination</div></div>
          
          <div className='nav-link-grp'><TbPackages className='userIcon'/> <div className='nav-link'>Explore package</div></div>
          {/* <div className='nav-link-grp'><FaUser className='userIcon'/> <div className='nav-link'>Profile</div></div>
          <div className='nav-link-grp'><FiLogIn className='userIcon'/> <div className='nav-link'>Login</div></div> */}
        </div>
          
      </div>

           
        <div className='nav-container-mob'>
        <div className='nav-logo'><img className='logo-image' src={logo} alt="logo"/></div>
          {/* <div className='nav-links'>
            <div className='nav-link-grp'><FaUser className='userIconMob'/> <div className='nav-link'>Profile</div></div>
            <div className='nav-link-grp'><FiLogIn className='userIconMob'/> <div className='nav-link'>Login</div></div>
          </div> */}
          <div className='nav-links'>
            <div className='nav-link-grp'><BsSearchHeart className='userIcon'/> <div className='nav-link'>Popular destination</div></div>
            <div className='nav-link-grp'><TbPackages className='userIconMob'/> <div className='nav-link'>Packages</div></div>
            <div className='nav-link-grp'><MdAddBusiness className='userIcon'/> <div className='nav-link'>List your business</div></div>
          </div>
          
      </div>
    </div>
    
    
  );
}
