import * as React from 'react';
import './Xautocomplete.css';

const Xautocomplete = ()=> {
  return (
    <div className='input-box'>
      
      <input className='x-input' type="text" id="location" />
      <div className='input-label'>Location</div>
    </div>
       
    
  );
}

export default Xautocomplete;
