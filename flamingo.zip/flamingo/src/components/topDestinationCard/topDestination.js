import React from 'react';
import './topDestination.css';
import destiPic from '../../resource/darj.JPG'




const TopDestination = () => {
  return (
    <div className='dest-card-container'>
        <div>
          <img className='dest-card-banner' src={destiPic}></img>
        </div>
        <div className='dest-card-text-container'>
          <div className='dest-card-text-title'>
               <strong>Darjeeling</strong>
          </div>
          
        </div>
    </div>
    
  )
}

export default TopDestination
