import React from 'react';
import './FavCard.css';
import stay from '../../resource/stay.jpg'




const FavCard = () => {
  return (
    <div className='fav-card-container'>
        <div>
          <img className='fav-card-banner' src={stay}></img>
        </div>
        <div className='fav-card-text-container'>
          <div className='fav-card-text-title'>
               <strong>Kalimpong |</strong> New Mountain view <br/>
               Per night <strong>Rs. 1500</strong> &nbsp; <s>Rs. 2000</s> &nbsp; <strong>25% Off</strong>
          </div>
          
        </div>
    </div>
    
  )
}

export default FavCard
