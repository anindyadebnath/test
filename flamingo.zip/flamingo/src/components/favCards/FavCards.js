import React from 'react';
import './FavCards.css';
import FavCard from './FavCard';
import TopDestination from '../topDestinationCard/topDestination';
import TourPackage from '../tourPackages/TourPackage';




const FavCards = () => {
  return (
    <div>
         <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Popular destination to explore</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            
            <div className='fav-cards-container dest-cards-container'>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               <TopDestination/>
               
            </div>
         </div>
         <hr/>
         <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Top rated stays.</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            <div className='fav-cards-container'>
               <FavCard/>
               <FavCard/>
               <FavCard/>
               <FavCard/>
               <FavCard/>
               <FavCard/>
               <FavCard/>
               <FavCard/>
               <FavCard/>
            </div>
         </div>   
         <hr/>
         <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Best tour packages.</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            <div className='fav-cards-container'>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
               <TourPackage/>
              
            </div>
         </div> 
    </div>
    
  )
}

export default FavCards
