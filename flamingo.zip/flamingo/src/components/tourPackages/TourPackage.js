import React from 'react';
import './TourPackage.css';
import packagePic from '../../resource/package.JPG'




const TourPackage = () => {
  return (
    <div className='package-card-container'>
        <div>
          <img className='package-card-banner' src={packagePic}></img>
        </div>
        <div className='package-card-text-container'>
          <div className='package-card-text-title'>
               <strong>Lamahata - 3N/4D</strong>  |
               Starting from <strong>Rs. 1500</strong>&nbsp;
              | Neque porro quisquam est qui dolorem
          </div>
          
        </div>
    </div>
    
  )
}

export default TourPackage
