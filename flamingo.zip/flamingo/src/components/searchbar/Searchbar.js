import React from 'react';
import './Searchbar.css';

const Searchbar = () => {
  return (
    <div className='search-container'>
        <div className='selection-block'>
            <div className='location-select'>
                <label className='location-select-label'>Location:</label>
                <select className='xselect'>
                    <option value="select">--Select area--</option>
                    <option value="javascript">JavaScript</option>
                    <option value="php">PHP</option>
                    <option value="java">Java</option>
                    <option value="golang">Golang</option>
                    <option value="python">Python</option>
                    <option value="c#">C#</option>
                    <option value="C++">C++</option>
                    <option value="erlang">Erlang</option>
                </select>
            </div>
            <div className='price-select'>
                <label className='price-select-label'>Price range:</label>
                <select className='xselect'>
                    <option value="select">--Select--</option>
                    <option value="under1500">Under 1500</option>
                    <option value="under2000">Under 2000</option>
                    <option value="under2500">Under 2500</option>
                    <option value="above2500">Above 2500</option>
                </select>
            </div>
        </div>
        
        {/* <div className='localtion-block'>
        <div className='location-select'>
            <label className='date-label'>Check - In</label>
            <input type='date' className='xdate' min='2024-04-03' ></input>
        </div>

        <div className='location-select'>
            <label className='date-label'>Check - Out</label>
            <input type='date' className='xdate'></input>
        </div>
        </div>
        
        <div className='guest-block'>
        <div className='guest-select'>
            <label className='guest-label'>Guest(above 10)</label>
            <span className='minus'>-</span>
            <span className='number'>01</span>
            <span className='plus'>+</span>
        </div>

        <div className='guest-select'>
            <label className='guest-label'>Guest(below 10)</label>
            <span className='minus'>-</span>
            <span className='number'>01</span>
            <span className='plus'>+</span>
        </div>
        </div> */}
        
        <div>
            <button className='btn-search'>Search</button>
        </div>
    </div>
  )
}

export default Searchbar
