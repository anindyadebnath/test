import React from 'react';
import './TextBanner.css';

const TextBanner = () => {
  return (
    <div className='hor-center banner-text'>
            Zero Commission on bookings. No Platform Fee. Direct booking with Owner.
    </div>
  )
}

export default TextBanner
