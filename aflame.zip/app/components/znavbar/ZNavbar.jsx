import { Offcanvas } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import navCss from './ZNavbar.css?url';
import { MdAddBusiness } from "react-icons/md";
import { useNavigate } from '@remix-run/react';



const destination =["a","b","c"];

function ZNavbar(props) {
    const expand = 'md';
    const navigate = useNavigate();


    return (
        <Navbar id='nav-main' key={expand} expand={expand} className="bg-body-tertiary" sticky="top">
          <Container fluid>
            <Navbar.Brand href="">
                <div className='nav-logo' ><img className='logo-image' src={""} alt="logo"/></div>
            </Navbar.Brand>
            <Navbar.Toggle aria-controls={`offcanvasNavbar-expand-${expand}`} />
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
              placement="end"
            >
              <Offcanvas.Header id='offNavCloseBtn' closeButton>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                  uRStay
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <Nav className="justify-content-start flex-grow-1 pe-3">
                <Nav.Link> <div className='nav-link' onClick={()=> navigate('/')}> Home</div></Nav.Link>
                    
                    {/* <Nav.Link><div className='nav-link' onClick={()=>onNavigate('/popular-destination')}><BsSearchHeart className='navIcon'/>Popular destination</div></Nav.Link> */}

                    <NavDropdown className='nav-link' title="Hotel & Stays" id="basic-nav-dropdown">
                      {props.places && props.places.length > 0 && props.places.filter(p=> p.business.includes('hotel')).map((e,i)=> {
                        return <NavDropdown.Item key={i} onClick={()=> navigate('place/'+e.code)} className='drop-item' >{e.name}</NavDropdown.Item>
                      })}
                    </NavDropdown>

                    <NavDropdown className='nav-link' title="Explore Package" id="basic-nav-dropdown">
                      {props.places && props.places.length > 0 && Object.values(props.places).filter(p=> p.business.includes('pack')).map((e,i)=> {
                        return <NavDropdown.Item key={i} onClick={()=> navigate('packages/'+e.code)} className='drop-item'>{e.name}</NavDropdown.Item>
                      })}
                    </NavDropdown>

                    {/* <Nav.Link> <div className='nav-link' ><MdAddBusiness  className='navIcon'/> List your business</div></Nav.Link> */}
                    <Nav.Link> <div className='nav-link' >List your business</div></Nav.Link>

                    {/* <Nav.Link><div className='nav-link' onClick={()=>onNavigate('/explore-package')}><TbPackages className='navIcon'/>Explore package</div></Nav.Link> */}
                </Nav>
              </Offcanvas.Body>
            </Navbar.Offcanvas>
          </Container>
        </Navbar>
    );
}

export default ZNavbar;

export function links() {
  return [
    { rel: "stylesheet", href: navCss }
  ];
}