import React, { useEffect } from 'react'
import packageDetailsCss from './PackageDetails.css?url'
import { MdNightShelter } from "react-icons/md";
import data from './mypackage.json'
import parse from 'html-react-parser'
import { TiTick } from "react-icons/ti";
import { RxCross2 } from "react-icons/rx";
import Image from 'react-bootstrap/Image';
import { MdOutlineDashboardCustomize } from "react-icons/md";
import ZCarousel from '../../../util/ZCarousel';
import { FaAngleLeft, FaAngleRight } from 'react-icons/fa';
import ZCard from '../../../util/ZCard';
import scrollerCss from '../../../styles/scroller.css?url'

const accordId = 'packageItemAcc-';

function PackageDetails(props) {

	useEffect(()=> {
        window.scrollTo({
            top: 0,
            left: 0,
            behavior: "smooth",
          });
    },[])

	const scrollHor = (side)=> {
		const el = document.getElementsByClassName('stay-cards-hor-con')[0];
		let scrollAmount =0;
		const distance = 350;
		const step =10;
		const speed = 10;
	 
		let slideTimer = setInterval(function() {   
			 if(side == 'right') {
				 el.scrollLeft += step;
				 } else {
				 el.scrollLeft -= step;
				 }
			 scrollAmount += step;
			 if(scrollAmount >= distance){
				 window.clearInterval(slideTimer);
			 }
		 }, speed);
		 
	 }
	 const packageBody = (e)=> {
		return (
		   <>
				 <span className='f-w-5'>{e.title} </span>| <span className='fsize13'>{e.locationDays}</span>
			</>
		)
	 }

	function onAccordianClick (index) {
		let el = document.getElementById(accordId+index);
		let nextSibling = el.nextElementSibling
		el.getElementsByClassName('plan-title')[0].classList.toggle("active");
		if (nextSibling.style.display === "block") {
			nextSibling.style.display = "none";
			el.style.borderRadius = '10px'
			el.style.backgroundColor = 'white'
		  } else {
			nextSibling.style.display = "block";
			el.style.borderRadius = '10px 10px 0px 0px'
			el.style.backgroundColor = '#e5dddd'
		  }
	}

  return (
		<div className='ztimeline'>
			<div className="d-flex flex-wrap container mt-3">
				<div className="itinery col-xl-7 col-12 me-3">
					<div className='title'>
						<h4 style={{color:'red'}}>{props.packageData.title} | <span className='fsize13'>{props.packageData.locationDays}</span></h4>
						<p>Duration: {props.packageData.duration}</p>
					</div>

					<div>
						<ZCarousel id={'packageCarousel'+data.code}/>
					</div>
					
					<ul className="timeline">

						{props.packageData.itinerary.map((d,i)=> {
							return (
								<li key={i} className='plan-day'>
									<button id={accordId+(i+1)} onClick={()=> onAccordianClick((i+1))} className={'package-item-acc'}>
										<div className='d-flex mb-2'>
											<div className='day-num'>{'Day ' + (i+1)}</div>
											<div className='plan-title ms-2'>{d.planTitle}</div>
											{d.nightStay && <div className='night-stay d-lg-block d-none'><div><MdNightShelter/>{d.nightStay}</div></div>}
										</div>
									
									</button>
									<div className='content'>{parse(d.content)}</div>
								</li>
							);
						})}
					</ul>
					<div className='inclusions'>
						<div className='title'>Inclusions</div>
						<ul>
							{Object.values(props.packageData.inclusion).map((e,i)=> {
								return <li key={i}><TiTick/> {e}</li>
							})}
						</ul>	
					</div>	

					<div className='exclusions'>
						<div className='title'>Exclusions</div>
						<ul>
							{Object.values(props.packageData.exclusion).map((e,i)=> {
								return <li key={i}><RxCross2/> {e}</li>
							})}
						</ul>	
					</div>	
				</div>

				<div className='col-xl-4 col-12'>
						<div className='package-price-container'>
							<div className='package-title'>
								{props.packageData.title}
							</div>
							<div className='details'>
								<div className='operator-name'>
									<div className='d-flex justify-content-center mb-2'>
										{/* <Image  src="https://images.pexels.com/photos/276299/pexels-photo-276299.jpeg" roundedCircle /><br/> */}
									</div>
									
									<span className='zlabel'>Tour Organizer :</span> <span className='zlabel-cont'>{props.packageData.provider}</span>
								</div>
								<div className='scheduleDates'>
									<span className='zlabel'>Upcoming tour starts on :</span> <span className='zlabel-cont'>{props.packageData.upcomingTourDates}</span>
								</div>
								
								<div className='pack-price-details'>
									<span className=''>Starting from <strong style={{color:'black'}}>Rs {props.packageData.price} </strong> per person on twin sharing</span>
									{props.packageData.customisable && <span className='shortDuration'> <MdOutlineDashboardCustomize/>Customizable</span>}
								</div>
								<div className='note'>
									<span> This site is not responsible for any monetory transaction with the operator. Please be cautious on any payment.</span>
								</div>
							</div>
							<div className='package-enquiry'>
								<label className='m-mid-text mt-1'>For Enquiries : </label>
								<label className='f-w-5'> {props.packageData.contact}</label>
							</div>
						</div>
				</div>
			</div>

			<div>
				<div className='d-flex justify-content-between'>
					<div className='f-w-7 mid-text mt-3 ms-4'>Other packages</div>
					<div className='mt-3 scroller-btn'>
							<button className='' onClick={()=>scrollHor('left')}><FaAngleLeft/></button>
							<button onClick={()=>scrollHor('right')}><FaAngleRight/></button>
					</div>
				</div>

				{props.otherPackages && props.otherPackages?.length > 0 && <div className='stay-cards-scroll1 mt-1 py-2'>
					{/* <button className='scroll-arrow' onClick={()=>scrollHor('left')}><FaAngleLeft/></button> */}
					<div className='stay-cards-hor-con'>
						{props.otherPackages && props.otherPackages?.length > 0 && props.otherPackages.map((e,i)=> <ZCard key={i} imageLink={e.imageLink} body={packageBody(e)} 
               			onClick={()=> navigate('/package/'+e.code)}
               			subtitle={<span>Rs.{e.price} - {e.duration}</span>}/>)}
					</div>
					{/* <button className='scroll-arrow' onClick={()=>scrollHor('right')}><FaAngleRight/></button> */}
				</div>}

			</div>
		
				
		</div>	
  )
}

export default PackageDetails

export function links() {
    return [
      { rel: "stylesheet", href: packageDetailsCss},
	  { rel: "stylesheet", href: scrollerCss}
    ];
  }