import React from 'react'
import viewPointsCss from './ViewPoints.css?url'
import ZCarousel from '../../../util/ZCarousel';

function ViewPoints(props) {
  // return (
  //   <div className='viewpoints-container'>
  //       <div className="accordion" id="placeAccordion">
  //         <div className="accordion-item acc-item">
  //           <div>
  //               <h2 className="accordion-header acc-header" id="headingOne">
  //                 <button className="accordion-button acc-btn" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
  //                     <div className='acc-title'>
  //                         <strong>Popular points to visit in {props.point.placeName} .</strong>
  //                     </div>
  //                 </button>
  //               </h2>
  //           </div>
            
            
  //           <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#placeAccordion">
  //             <div className="accordion-body acc-body">
  //               <ViewPoint {...props}/>
  //             </div>
  //           </div>
  //         </div>
  //       </div>
  //   </div>
  // )
  return (
          <ZCarousel images={ Object.values(props.point.images)} id={'viewPoints'}/>
  )
    


}

export default ViewPoints

export function links() {
  return [{ rel: "stylesheet", href: viewPointsCss}];
}