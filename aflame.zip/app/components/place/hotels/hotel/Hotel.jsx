import React from 'react'
import hotelCss from './Hotel.css?url'
import { FaStar } from "react-icons/fa";
import { FaRegStar } from "react-icons/fa";
import { CiLocationOn } from "react-icons/ci";
import { TiTick } from "react-icons/ti";
import { useNavigate } from 'react-router-dom';
import { FaArrowRightLong } from "react-icons/fa6";
import ZCarousel from '../../../../util/ZCarousel';

function Hotel(props) {

    const navigate = useNavigate()

    const getStar = (rating) => {
        let arr = [1,2,3,4,5];
           const d = arr.map(e=> {
               if(e<=rating) {
                return <FaStar/>
               } else {
                return <FaRegStar/>
               }
            })
            return d
           
    }

  return (
    <div className='hotel-con col row'>
        <div className='col-xl-5 col-lg-5 hotel-img'>
            <ZCarousel images={Object.values(props.stay.images)} divClass= {'hotel-pics'} id={'stayCard'+props.stay.code+'pics'}/>
        </div>
        <div className='col-xl-7 col-lg-7'>
            <div className='hotel-detail'> 
                <div className='imp-name'>{props.stay.name}</div>
                <div><CiLocationOn/> <span className='hotel-location'>{props.stay.location} </span> | <span className='hotel-location-help'> {props.stay.locHelp}
                </span></div>
                <div className='hotel-short-desc'>
                    {props.stay.shortDesc}
                </div>
                <div>
                <div className="">
                    <ul className='amenities-list'>
                        {Object.values(props.stay.amenities).map((e,i)=> {
                            return <li><TiTick />{e}</li>
                        })}
                    </ul>
                    </div>
                </div>
            </div>
            
            <div className='row'>
                <div className='col-xl-8 col-lg-8 mt-3'> 
                    <span className='mid-text'>Booking from </span>
                    <span className='mid-text f-w-5'>₹{props.stay.finalPrice} </span><s className='grey-text'>₹{props.stay.price}</s>
                    <span className='m-mid-text discount-red'> {props.stay.discount}% OFF </span>
                    <span className='mid-text'>per night </span>
                </div>
                <div className='col-xl-4 col-lg-4 hor-center mt-3'>
                <button onClick={()=> navigate("stay/"+props.stay.code)} class="searchBtn w-75"><strong> Get Deatils</strong> <FaArrowRightLong/></button>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Hotel

export function links() {
    return [
      { rel: "stylesheet", href: hotelCss }
    ];
  }