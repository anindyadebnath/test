import React, { useEffect, useState } from 'react'
import Hotels, {links as hotelsCss} from './hotels/Hotels'
import ViewPoints, {links as viewPointsCss} from './view-points/ViewPoints'
import placeCss from './Place.css?url';

function Place(props) {

  return (
    <div className='place-container'>
       {props.viewPoint && Object.values(props.viewPoint.images).length > 0 && <ViewPoints point ={props.viewPoint}/>}
       <Hotels stayCards = {props.stays}/>
    </div>
  )
}

export default Place

export function links() {
  return [{rel:'stylesheet', href:placeCss}, ...viewPointsCss(), ...hotelsCss()];
}