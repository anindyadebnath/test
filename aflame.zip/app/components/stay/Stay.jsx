import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import stayCss from './Stay.css?url'
import { MdOutlineLocationOn } from "react-icons/md";
import { BsCheckAll } from "react-icons/bs";
import { BsCardChecklist } from "react-icons/bs";
import { IoPricetagsOutline } from "react-icons/io5";
import { MdOutlinePolicy } from "react-icons/md";
import { FaCheckCircle } from "react-icons/fa";
import {findPolicy,findSubPolicy} from '../../util/RulePolicy'
import { MdOutlineBedroomParent } from "react-icons/md";
import Button from 'react-bootstrap/Button';
import { MdOutlinePermPhoneMsg } from "react-icons/md";
// import ZModalContact from '../../util/ZModalContact.js';
import {stayCardBody, links as favCardsCss} from '../home/favCards/FavCards';
import ZCard from '../../util/ZCard';
import { FaAngleLeft } from "react-icons/fa6";
import { FaAngleRight } from "react-icons/fa6";
import ZBreadCrumb from '../../util/ZBreadCrumb';
import ZModal from '../../util/ZModal';
import ZModalContact from '../../util/ZModalContact';
import { getPhoneByStayCode } from '../../util/ZAxios';
import BlurredUpImage from '../../util/BlurredUpImage';



function Stay(props) {

    const [hotelPhone,setHotelPhone] = useState(null)
    const [mapModalShow, setMapModalShow] = useState(false)
    const [contactModalShow, setContactModalShow] = useState(false)
    const [contactIsInProgress, setContactIsInProgress] = useState(false)
    const [stayDto, setStayDto] = useState()
    const crumbs = [
        {
            active: false,
            title : 'Home',
            linkProps : {to: '/'}  
        },
        {
            active: false,
            title : props.stayData.stay.destination.name,
            linkProps : {to: '/place/'+ props.stayData.stay.destination.code}
        },
        {
            active: true,
            title : props.stayData.stay.name,
            linkProps : {}
        }
    ];

    const scrollHor = (side)=> {
       const el = document.getElementsByClassName('stay-cards-hor-con')[0];
       let scrollAmount =0;
       const distance = 350;
       const step =10;
       const speed = 10;

       let slideTimer = setInterval(function() {   
            if(side == 'right') {
                el.scrollLeft += step;
                } else {
                el.scrollLeft -= step;
                }
            scrollAmount += step;
            if(scrollAmount >= distance){
                window.clearInterval(slideTimer);
            }
        }, speed);
        
    }

    const getPhone = (code)=> {
        setContactIsInProgress(true);
        getPhoneByStayCode(code).then(res=> {
            setContactModalShow(true)
            setHotelPhone(res.data)
            setContactIsInProgress(false);
        })
    }


    const navigate = useNavigate();

    const hotel = {
        "code" : "SH7162",
        "name" : "Say Homes Hi-De Darjeeling",
        "destination" : {
            "code" : "DJ8129",
            "name" : "Darjeeling"
        },
        "addeess" : " Between Batasia Loop and Dali monastery, Chotta Batasia Hi De Stay, Hill Cart Road, P.O Ghoom, Darjeeling, West Bengal 734102",
        "locHelp" : "",
        "attractions" : ["Tiger Hill","Japanese Temple","Darjeeling HImalayan Zoo","Tenzing & Gompu Rock"],
        "distFromNear" : "",
        "tags" : [],
        "description" : "Say Homes Hi-De is a good standard Homestay located in Darjeeling, a well known tourist destination  in West Bengal. Total 8 rooms available here. All rooms are well furnished and spacious with attached bathroom and geyser. ",
        "thumbnail" : "https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600",
        "images" : [
            {"tag" : "tag1",
             "imgLink" : "https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600"
            },
            {"tag" : "tag2",
             "imgLink" : "https://images.pexels.com/photos/1563356/pexels-photo-1563356.jpeg?auto=compress&cs=tinysrgb&w=600"
            },
            {"tag" : "tag3",
             "imgLink" : "https://images.pexels.com/photos/1323550/pexels-photo-1323550.jpeg?auto=compress&cs=tinysrgb&w=600"
            },
        ],
        "fourImages" : [
            "https://images.pexels.com/photos/1563356/pexels-photo-1563356.jpeg?auto=compress&cs=tinysrgb&w=600",
            "https://images.pexels.com/photos/1563356/pexels-photo-1563356.jpeg?auto=compress&cs=tinysrgb&w=600",
            "https://images.pexels.com/photos/1563356/pexels-photo-1563356.jpeg?auto=compress&cs=tinysrgb&w=600",
            "https://images.pexels.com/photos/1563356/pexels-photo-1563356.jpeg?auto=compress&cs=tinysrgb&w=600"
        ],
        "amenities" : ["Wifi","AC","TV","Locker","Barbeque","Kitchen","Bonfire","Swimming Pool","Room Service"],
        "timings" : {
            "checkIn" : "12 PM",
            "checkOut" : "10 AM"
        },
        "tarrif" : [
            {
                "title" : "Family Room + breakfast",
                "priceDesc" : "Starting from 1100 to 1400 per head",
                "desc" : "Can accomodate 2 adults and one child."
            },
            {
                "title" : "Deluxe room + Breakfast",
                "priceDesc" : "Starting from 1300 to 1500 per head",
                "desc" : "Large room with Sofa and table. Has almira and dressing table. Can accomodate 2 adults and one child."
            },
            {
                "title" : "Super Deluxe room + Breakfast",
                "priceDesc" : "Starting from 1500 to 1700 per head",
                "desc" : "With a big balcony and window with mountain view. Large room with Sofa and table. Has almira and dressing table. Can accomodate 2 adults and one child."
            }
        ],
        "impPolicy" : [1,2,3,7,9,10,12],
        "price" : 1200,
        "discount" : 10,
        "isActive" : true,
        "isDeleted" : false
    }
    
    return ( <div className='container stay'>
            <div className=' mt-3'><ZBreadCrumb links={crumbs}/></div>
            <div className='row'>
                <div id="stayImgCarousel" className="carousel slide col-md-6 px-0" data-bs-ride="carousel">
                    <div className="carousel-indicators">
                        {Object.values(props.stayData.stay.images).map((e,i)=> {
                            return (
                                <button key={i} type="button" data-bs-target="#stayImgCarousel" data-bs-slide-to={i.toString()} className= {i == 0 ? 'active' : ''} aria-current={i == 0 ? 'true' : 'false'} aria-label={'Slide '+i}></button>
                            );
                        })}
                    </div>
                    <div className="carousel-inner">
                    {/* data-bs-interval="100000" */}
                            {Object.values(props.stayData.stay.images).map((e,i)=> {
                                return (
                                    <div key={i} className={i == 0 ? 'carousel-item active' : 'carousel-item'}>
                                        <div className='carousel-stay row'>
                                            <div className='carousel-stay-img'>
                                                <img src={e.imgLink} className="img-fluid w-100" alt={'image '+i}/>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                    </div>
                    {/* <button className="carousel-control-prev" type="button" data-bs-target="#stayImgCarousel" data-bs-slide="prev">
                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Previous</span>
                    </button>
                    <button className="carousel-control-next" type="button" data-bs-target="#stayImgCarousel" data-bs-slide="next">
                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Next</span>
                    </button> */}
                </div> 
                <div className="col-12 col-md-6 px-3 d-none d-md-block">
                    <div className="row stay-sub-image">
                        { props.stayData.stay.fourImages.map((e,i)=> {
                            return (
                                <div key={i} className='col-6 px-1  pb-1'>
                            {/* <img src={e} className="img-fluid w-100" alt={'image'}/> */}
                            <BlurredUpImage src={e} />
                        </div>
                            )
                        })}  
                    </div>
                </div>
            </div>

            <div className='stay-title'>
                {props.stayData.stay.name}
            </div>
            <div className='stay-addeess'>
                <MdOutlineLocationOn />{props.stayData.stay.addeess}
                <a className='map-link' onClick={()=> setMapModalShow(true)}>View in map</a>
                <ZModal
                size='lg'
                title={props.stayData.stay.name}
                body={<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1886677.1422169076!2d85.90359295625!3d22.5448082!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a02771346ae015d%3A0xb540e4bce39763!2sVictoria%20Memorial!5e0!3m2!1sen!2sin!4v1718514557194!5m2!1sen!2sin" width="100%" height="450" style={{border:'0'}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>}
                show={mapModalShow}
                onHide={() => setMapModalShow(false)}/>
            </div>
            <div className='mt-3 stay-price '>
                <span>Start your booking from </span>
                <span className='f-w-5'>₹{props.stayData.stay.price * ((100-props.stayData.stay.discount)/100)} </span><s className='grey-text'>₹{props.stayData.stay.price}</s>
                <span className='m-mid-text discount-red'> {props.stayData.stay.discount}% OFF </span>
                <span>per night </span>
                
            </div>
            <div>
                <span className='m-mid-text'>Want to know more ?</span> {!hotelPhone && <span className='get-contact-btn'>
                <button  className='searchBtn' onClick={()=> getPhone(props.stayData.stay.code)} ><MdOutlinePermPhoneMsg/> Contact</button></span>}
                {contactIsInProgress && <span> please wait...</span>}
                {hotelPhone && <span className='m-mid-text f-w-5' onClick={()=> setContactModalShow(true)}><a style={{textDecoration: 'underline', cursor:'pointer'}}>view contact</a> </span>}
                {<ZModalContact
                show={contactModalShow}
                onHide={() => setContactModalShow(false)}/>}
            </div>
            {/* <div className='stay-addeess-help'>
                <IoMdHelpCircleOutline />{hotel.locHelp}
            </div> */}
            <div className='stay-container mt-5'>
                <div className='f-w-5 m-mid-text my-1'>
                    <span >Check in-</span> <span className='grey-text'>{props.stayData.stay.timings.checkIn} </span>
                    <span className='ms-3'>Check out- </span> <span className='grey-text'>{props.stayData.stay.timings.checkOut}</span>
                </div>
                <div className='mt-3'>
                    <div className='f-w-5 mid-text'>About your stay</div>
                    {props.stayData.stay.description}
                </div>
                
                <div className='row'>
                    <div className='mt-3 col-md-6 col-lg-5'>
                        <div className='f-w-5 mid-text'>Attraction near by</div>
                        <ul>
                            {Object.values(props.stayData.stay.attractions).map((e,i)=> {
                                return <li key={i}>{e}</li>    
                            })}
                        </ul>
                    </div>
                    
                    <div className='mt-3 col-md-6 col-lg-7'>
                        <div className='f-w-5 mid-text'><BsCardChecklist  style={{width:'30px',height:'40px'}}/> Amenities provided</div>
                        
                        <ul className='amenities-list'>
                            {Object.values(props.stayData.stay.amenities).map((e,i)=> {
                                return <li key={i}><BsCheckAll />{e}</li>
                            })}
                        </ul>
                    </div>  
                </div>
                <div>
                    <div className='f-w-5 mid-text'><MdOutlineBedroomParent style={{width:'30px',height:'40px'}}/> Room type and charges</div>
                    {Object.values(props.stayData.stay.tariff).map((e,i)=> {
                        return (
                            <div key={i} className='ms-4'>
                                <div><IoPricetagsOutline/> <span className='fsize17 f-w-5'>{e.title}</span> 
                                <span className='m-mid-text room-price'> - {e.priceDesc}</span></div>
                                    <ul>
                                        <li className='m-mid-text'>{e.desc}</li>
                                    </ul>
                            </div>
                            
                        )
                    })}

                </div>

                <div className='mt-3'>
                        <div className='f-w-5 mid-text'><MdOutlinePolicy  style={{width:'30px',height:'40px'}}/> Property rules and policy</div>
                        
                        <ul className='policy-list'>
                            {Object.values(props.stayData.stay.impPolicy).map((e,i)=> {
                                return <li key={i} className='m-mid-text'><FaCheckCircle/> {findSubPolicy(e)}</li>
                            })}
                        </ul>
                    </div> 
                
                
            </div>
            <div>
                <div className='d-flex justify-content-between'>
                    <div className='f-w-7 mid-text mt-3'>Simmilar properties</div>
                    <div className='mt-3 scroller-btn'>
                            <button className='' onClick={()=>scrollHor('left')}><FaAngleLeft/></button>
                            <button onClick={()=>scrollHor('right')}><FaAngleRight/></button>
                    </div>
                </div>

                {props.stayData.relatedStays && props.stayData.relatedStays?.length > 0 && <div className='stay-cards-scroll1 mt-1 py-2'>
                    {/* <button className='scroll-arrow' onClick={()=>scrollHor('left')}><FaAngleLeft/></button> */}
                    <div className='stay-cards-hor-con'>
                        {props.stayData.relatedStays && props.stayData.relatedStays?.length > 0 && props.stayData.relatedStays.map((e,i)=> <ZCard key={i} onClick={()=> navigate('/place/'+e.locationCode+ '/stay/'+e.code)} imageLink={e.thumbnail} body={stayCardBody(e)} subtitle={e.location} />)}
                    </div>
                    {/* <button className='scroll-arrow' onClick={()=>scrollHor('right')}><FaAngleRight/></button> */}
                </div>}

            </div>
            
        </div> )
    }

export default Stay

export function links() {
    return [{ rel: "stylesheet", href: stayCss}];
  }