import React from 'react'
import './OfferBanner.css'
import sale2 from '../../../resource/sale2.jpg'
import pickup from '../../../resource/pickup.jpg'

const OfferBanner = () => {
  return (
    <div className='offer-banner'>
        
        <img className='offer-image ' src={sale2} alt="sale"/>
        
        <img className='offer-image ' src={pickup} alt="sale"/>
        
    </div>
  )
}

export default OfferBanner
