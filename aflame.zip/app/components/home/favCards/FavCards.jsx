import React, { useEffect, useState } from 'react';
import favCardsCss from './FavCards.css?url';
import ZCard from '../../../util/ZCard';
import { useNavigate } from 'react-router-dom';
import { FaAngleLeft } from "react-icons/fa6";
import { FaAngleRight } from "react-icons/fa6";
import ZImageOverlay, {links as imageOverlayCss} from '../../../util/image-overlay/ZImageOverlay';
import scrollerCss from '../../../styles/scroller.css?url'

export const stayCardBody = (e)=> {
   return (
      <>
         <span className='f-w-5'></span> {e.name} <br/>
         Per night <span className='f-w-5'>Rs. {e.finalPrice}</span> <s>Rs.{e.price}</s> <span className='discount'>{e.discount}% Off</span>
      </>
      
   )}


const FavCards = (props) => {

   const navigate = useNavigate();

   const scrollHor = (side)=> {
      const el = document.getElementsByClassName('stay-cards-hor-con')[0];
      let scrollAmount =0;
      const distance = 350;
      const step =10;
      const speed = 10;

      let slideTimer = setInterval(function() {   
           if(side == 'right') {
               el.scrollLeft += step;
               } else {
               el.scrollLeft -= step;
               }
           scrollAmount += step;
           if(scrollAmount >= distance){
               window.clearInterval(slideTimer);
           }
       }, speed);
       
   }

   const dests = ['Darjeeling','Sittong','Dooars','Sikkim','Gangtok','Sundarban','Bishnupur','Purulia'];
   // const stays = [
   //    {
   //       'name' : 'Roof top Resort',
   //       'code' : 'AFSKF',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Sikkim',
   //       'price' : 1000,
   //       'discount' : 10
   //    },
   //    {
   //       'name' : 'Fast travel',
   //       'code' : 'AFSK1',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Dooars',
   //       'price' : 1200,
   //       'discount' : 15
   //    },
   //    {
   //       'name' : 'Mountain view Resort',
   //       'code' : 'DKL45',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Darjeeling',
   //       'price' : 1500,
   //       'discount' : 10
   //    },
   //    {
   //       'name' : 'Open air residency',
   //       'code' : 'IRSKM',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Sittong',
   //       'price' : 1200,
   //       'discount' : 10
   //    },
   //    {
   //       'name' : 'Hill Homestay',
   //       'code' : '3HJK9',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Purulia',
   //       'price' : 900,
   //       'discount' : 10
   //    },
   //    {
   //       'name' : 'Sunayan Stay',
   //       'code' : 'ETJFL',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Sundarban',
   //       'price' : 1800,
   //       'discount' : 10
   //    },
   //    {
   //       'name' : 'River side Homestay',
   //       'code' : 'PDJAK',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Murti',
   //       'price' : 900,
   //       'discount' : 10
   //    },
   //    {
   //       'name' : 'Jungle book Stay',
   //       'code' : 'QOFSJ',
   //       'imageLink' : 'https://images.pexels.com/photos/2176593/pexels-photo-2176593.jpeg?auto=compress&cs=tinysrgb&w=600',
   //       'location' : 'Sundarban',
   //       'price' : 1600,
   //       'discount' : 10
   //    }
   // ]
   const img1 = 'https://images.pexels.com/photos/23623515/pexels-photo-23623515/free-photo-of-a-building-in-madrid.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load'
   // const tourPackages = [
   //    {
   //       imageLink : img1,
   //       location : 'Lamahata',
   //       duration : '3N/4D',
   //       price : 3200,
   //       providerName : 'Neque porro quisquam'
   //    },
   //    {
   //       imageLink : img1,
   //       location : 'Sundarban',
   //       duration : '2N/3D',
   //       price : 3000,
   //       providerName : 'Akash tour and travel'
   //    },
   //    {
   //       imageLink : 'https://images.pexels.com/photos/21820339/pexels-photo-21820339/free-photo-of-luna-en-getafe.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load',
   //       location : 'Lamahata',
   //       duration : '3N/4D',
   //       price : 3200,
   //       providerName : 'Neque porro quisquam'
   //    },
   //    {
   //       imageLink : img1,
   //       location : 'Sundarban',
   //       duration : '2N/3D',
   //       price : 3000,
   //       providerName : 'Akash tour and travel'
   //    },
   //    {
   //       imageLink : img1,
   //       location : 'Lamahata',
   //       duration : '3N/4D',
   //       price : 3200,
   //       providerName : 'Neque porro quisquam'
   //    },
   //    {
   //       imageLink : 'https://images.pexels.com/photos/21820339/pexels-photo-21820339/free-photo-of-luna-en-getafe.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load',
   //       location : 'Sundarban',
   //       duration : '2N/3D',
   //       price : 3000,
   //       providerName : 'Akash tour and travel'
   //    },
   //    {
   //       imageLink : img1,
   //       location : 'Lamahata',
   //       duration : '3N/4D',
   //       price : 3200,
   //       providerName : 'Neque porro quisquam'
   //    },
   //    {
   //       imageLink : img1,
   //       location : 'Sundarban',
   //       duration : '2N/3D',
   //       price : 3000,
   //       providerName : 'Akash tour and travel'
   //    }
   // ]

  
   
   const packageBody = (e)=> {
      return (
         // <div>
         //       Starting from <span className='f-w-5'>Rs. {e.price}</span>&nbsp;
         //      | {e.providerName}
         //  </div>
         <>
               <span className='f-w-5'>{e.title} </span>| <span className='fsize13'>{e.locationDays}</span>
          </>
      )
   }


  return (
    <div>
         <div>
            <div className='d-flex justify-content-between'>
               <div className='f-w-7 mid-text mt-3 ps-4'>Popular destination to explore</div>
               <div className='mt-3 scroller-btn pe-3'>
                        <button className='' onClick={()=>scrollHor('left')}><FaAngleLeft/></button>
                        <button onClick={()=>scrollHor('right')}><FaAngleRight/></button>
               </div>
            </div>
            

            {props.places && props.places.length > 0 && <div className='stay-cards-scroll mt-1 py-2'>
               <div className='stay-cards-hor-con'>
                  {props.places && props.places.length > 0 && props.places.filter(p=> p.business.includes('hotel-pack')).map((e,i)=> <ZImageOverlay key={i} hotelOnClick={()=> navigate('/place/'+e.code)} thumbnail={e.thumbnail} name={e.name}/>)}
               </div>
            </div>}
         </div>






         <hr/>
        <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Top rated stays.</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            <div className='stay-cards-container'>
               {props.stays && props.stays.length > 0 && props.stays.map((e,i)=> <ZCard key={i} onClick={()=> navigate('/place/'+ e.locationCode +'/stay/'+e.code)} imageLink={e.thumbnail} body={stayCardBody(e)} subtitle={e.location}/>)}
            </div>
         </div>
         
         <hr/>
         <div className='dest-cards-container-main'>
            <div className='hor-center flex-col'>
               <div className='hor-center font-large'><strong>Best tour packages.</strong></div>
               <div className='hor-center mg-auto dest-desc'><p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
            </div>
            <div className='stay-cards-container'>
               {props.tourPackages && props.tourPackages.length > 0 && props.tourPackages.map((e,i)=> <ZCard key={i} imageLink={e.imageLink} body={packageBody(e)} 
               onClick={()=> navigate('/package/'+e.code)}
               subtitle={<span>Rs.{e.price} - {e.duration}</span>}/>)}
            </div>
         </div>
    </div>
    
  )
}

export default FavCards

export function links() {
   return [{rel:'stylesheet', href:favCardsCss}, {rel:'stylesheet', href:scrollerCss}, ...imageOverlayCss()]
 }


