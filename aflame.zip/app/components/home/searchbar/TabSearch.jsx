import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import React, { useEffect } from 'react';
import tabSearchCss from './TabSearch.css?url';
import LocSearchbar, {links as locSearchbarCss} from './LocSearchbar';
import { useNavigate, useRouteLoaderData } from '@remix-run/react';
import { tagsOptions } from '../../../util/DataUtil';



function TabSearch() {
  
  const rootPlaceOptions = useRouteLoaderData('root')
  const navigate = useNavigate()

  useEffect(()=> {
    Object.values(tagsOptions).map(t=> {t.checked = false; return t})
  },[])

  const onSearchBtn = (locOption,priceOption, tagOption) => {
    let params = new Array()
    let tags = Object.values(tagOption).filter(t=> t.checked).map(t=> t.code).join(',') 
    let path = '/place/'+locOption+'?'
    priceOption && params.push('price='+priceOption)
    tags && params.push('tags='+tags)
    path = path + params.join('&')
    navigate(path)
  }

  const onGoBtn = (locOption) => {
    navigate('/packages/'+locOption)
  }
  
  return (
    <Tabs
      defaultActiveKey="hotel"
      id="homeSearchTabs"
      justify
    >
      <Tab eventKey="hotel" title="Hotel & Stays">
            <LocSearchbar tagsOptions={Object.values(tagsOptions)}
             placeOptions={Object.values(rootPlaceOptions).filter(p=> p.business.includes('hotel'))} 
             onSearchBtn = {onSearchBtn}
             isHotel={true}/>
      </Tab>
      <Tab eventKey="package" title="Tour Package">
        <LocSearchbar tagsOptions={Object.values(tagsOptions)}
              placeOptions={Object.values(rootPlaceOptions).filter(p=> p.business.includes('pack'))} 
              onGoBtn = {onGoBtn}
              isPackage={true}/>
      </Tab>
      {/* <Tab eventKey="cab" title="Cab">
            
      </Tab> */}
    </Tabs>
  );
}

export default TabSearch;

export function links() {
  return [{rel:'stylesheet', href:tabSearchCss}, ...locSearchbarCss()]
}