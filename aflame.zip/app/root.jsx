import {
  Links,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
  useLoaderData,
  useNavigation
} from "@remix-run/react";
import appStylesHref from "./app.css?url";
import { getPlacesDetails } from "./util/ZAxios";
import ZNavbar, {links as navBarCss} from "./components/znavbar/ZNavbar";
import bsCss from '../node_modules/bootstrap/dist/css/bootstrap.min.css?url';
import Footer, {links as footerCss} from "./components/footer/Footer";
import GrowRowSpinner from "./util/GrowRowSpinner";

export function Layout({ children }) {

  let places = useLoaderData();


  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
      </head>
      <body>
      <ZNavbar places={places}/>
        {children}
       <Footer/> 
        <ScrollRestoration />
        {<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossOrigin="anonymous"></script>}
        {/* {<script src= "/app/node_modules/bootstrap/dist/js/bootstrap.bundle.js"></script>} */}
        <Scripts />
      </body>
    </html>
  );
}

export default function App() {
  const { state } = useNavigation();
  
  if (state === "loading") {
    return <GrowRowSpinner/>
  }
  return <Outlet />;
}


export function links() {
  return [...navBarCss(), ...footerCss(),
    { rel: "stylesheet", href: appStylesHref }, {rel:'stylesheet', href: bsCss}
    // {rel: "stylesheet", href: "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"},
  ];
} 


export async function loader() {
  const response = await getPlacesDetails();
  return response.data;
}