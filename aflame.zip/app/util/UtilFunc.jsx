
export function isSmallDevice() {
    return false
}