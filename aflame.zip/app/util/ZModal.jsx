import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { isSmallDevice } from './UtilFunc';

function ZModal(props) {
  return (
    <Modal
      {...props}
      size={props.size}
      aria-labelledby="contained-modal-title-vcenter"
      centered={isSmallDevice() ? false : true}
      className={props.class}
    >
      <Modal.Header closeButton>
        {props.title && 
            <Modal.Title id="contained-modal-title-vcenter">
                {props.title}
            </Modal.Title>
        }
        
      </Modal.Header>
      <Modal.Body>
        {props.body}
      </Modal.Body>
      <Modal.Footer>
        {props.secondary && <Button variant="secondary" onClick={props.onHide}> Close</Button>}
        {props.primary && <Button variant="primary" style={{backgroundColor: '--var(ZPrimary)'}} onClick={props.onAction}> Apply Filter</Button>}
      </Modal.Footer>
    </Modal>
  )
}

export default ZModal