import React from 'react'
import zImageOverlayCss from './ZImageOverlay.css?url'
import { BsArrowRight } from "react-icons/bs";

function ZImageOverlay(props) {
  return (
    <div className='package-card'>
        <img src={props.thumbnail}></img>
        {/* <img src='https://images.pexels.com/photos/533769/pexels-photo-533769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'></img> */}

        <div className='img-text-box d-flex justify-content-between'>
            <div className='f-w-7 d-flex align-items-center'>{props.name}</div>
            <div className='d-flex flex-column'>
                <div className='m-mid-text f-w-5 d-flex justify-content-end cursor-pointer' onClick={props.hotelOnClick}>Hotel/Stay <BsArrowRight /></div>
                <div className='m-mid-text f-w-5 d-flex justify-content-end cursor-pointer'>Package <BsArrowRight /></div>
            </div>
            
        </div>
    </div>
  )
}

export default ZImageOverlay

export function links() {
  return [{rel:'stylesheet', href:zImageOverlayCss}]
}