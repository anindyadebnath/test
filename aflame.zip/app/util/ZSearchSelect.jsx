import { useEffect, useState } from "react";
import { isSmallDevice } from "./UtilFunc";





export default function ZSearchSelect(props) {

    const [keyInput, setKeyInput] = useState('');
    const [options, setOptions] = useState(props.options)

    function searchInputOnFocus() {
        let el = document.getElementById(props.btnId).getElementsByTagName('ul')[0]
        el.classList.add('show')

        if(document.getElementById("multiSelectCancel")) {
            document.getElementById("multiSelectCancel").click()
        }
            
        if(isSmallDevice()) {
            let elPos = el.getBoundingClientRect().top
            let offsetPosition = elPos + window.pageYOffset - 130;
            window.scrollTo({
                top: offsetPosition,
                left: 0,
                behavior: "smooth",
            });
        } 
    }

    function searchInputOnBlur() {
        setTimeout(()=>{
            document.getElementById(props.btnId).getElementsByTagName('ul')[0].classList.remove('show')
        },300)
        
    }

    function onDropDownSelect(e) {
        document.getElementById(props.btnId).getElementsByTagName('input')[0].value = e.name
        props.listClick(e)
    }

    useEffect(()=> {
        if(keyInput == '') {
            setOptions(props.options)
        } else {
            let filterOpts = props.options.filter(o=> o.name.toLowerCase().indexOf(keyInput.toLowerCase()) > -1)
            setOptions(filterOpts.length == 0 ? ['-------'] : filterOpts)
        }
    },[keyInput])



    return (
        <div className="btn-group" id={props.btnId}>
            <input type="text" className="form-control border-0 border-bottom shadow-none mb-2" 
                   placeholder={props.placeHolder}
                   onInput={(e)=> setKeyInput(e.target.value)}
                   onFocus={()=> searchInputOnFocus()}
                   onBlur={()=> searchInputOnBlur()}
                   />
                
            <ul className="dropdown-menu mt-5" aria-labelledby={props.btnId}>
                {Object.values(options).map((e,i)=> {
                    return <li key={i}><div className="dropdown-item" onClick={()=>onDropDownSelect(e)}>{e.name}</div></li>
                })}
            </ul>
        </div>
    )
}