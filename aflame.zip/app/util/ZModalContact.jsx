import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function ZModalContact(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        
        <Modal.Title id="contained-modal-title-vcenter">
            Contact Details
        </Modal.Title>
        
      </Modal.Header>
      <Modal.Body>
        <div className='container'>
            <div className='hor-center d-flex imp-name mb-4'>Say Homes Hi-De Darjeeling</div>
            <div className='hor-center d-flex mid-text mb-5'> For any booking related query call 9876543210</div>

            <div className='hor-center d-flex m-mid-text mb-2'><span className='grey-text'>Any difficulties? Please connect with us by whats app </span>&nbsp;<span className='f-w-5'>765432123 </span></div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={props.onHide}> Close</Button>
      </Modal.Footer>
    </Modal>
  )
}

export default ZModalContact