import { useEffect, useState } from "react";
import { RxCross1 } from "react-icons/rx";
import { isSmallDevice } from "./UtilFunc";



export function multiSelectOnBlur() {
    searchInputOnBlur()
}

export default function ZSearchMultiSelect(props) {

    const [keyInput, setKeyInput] = useState('');
    const [options, setOptions] = useState(props.options)
    const [dropdownOpen, setDropdownOpen] = useState(false)

    function searchInputOnFocus() {
        let el = document.getElementById(props.btnId).getElementsByTagName('ul')[0]
        el.classList.add('show')
        setDropdownOpen(true)

        if(isSmallDevice()) {
            let elPos = el.getBoundingClientRect().top
            let offsetPosition = elPos + window.pageYOffset - 150;
            window.scrollTo({
                top: offsetPosition,
                left: 0,
                behavior: "smooth",
            });
        } 
    }

    function searchInputOnBlur() {
        let el = document.getElementById(props.btnId).getElementsByTagName('ul')[0]
        el.classList.remove('show')
        setDropdownOpen(false)
    }

    function onDropDownSelect(e) {
        document.getElementById(props.btnId).getElementsByTagName('input')[0].focus()
        e.checked = !e.checked
        props.listClick(e)
    }

    useEffect(()=> {
        if(keyInput == '') {
            setOptions(props.options)
        } else {
            let filterOpts = props.options.filter(o=> o.name.toLowerCase().indexOf(keyInput.toLowerCase()) > -1)
            setOptions(filterOpts.length == 0 ? ['-------'] : filterOpts)
        }
    },[keyInput])



    return (
        <div className="btn-group" id={props.btnId}
            >
            
            <input type="text" className="form-control border-0 border-bottom shadow-none mb-2 ms-2" 
                   placeholder="Tags..." 
                   onFocus={()=> searchInputOnFocus()}
                   value={props.value}
            />
            {dropdownOpen && <span id="multiSelectCancel" onClick={()=> searchInputOnBlur()}><RxCross1/></span> }

            <ul className="dropdown-menu mt-5" aria-labelledby={props.btnId}>
                <input type="text" className="form-control border-0 border-bottom shadow-none mb-2" 
                    placeholder="Search..." 
                    onInput={(e)=> {setKeyInput(e.target.value)}}
                    
                />
                {Object.values(options).map((e,i)=> {
                    return <li key={i} className="dropdown-item d-flex justify-content-start" onClick={()=>onDropDownSelect(e)} ><input type="checkbox" checked={e.checked} onChange={()=> {}} /> <label className="ms-3">{e.name}</label></li>
                })}
            </ul>
        </div>
    )
}