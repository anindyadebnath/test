export const tagsOptions = [
    {
      "name" : "Swiming Pool",
      "checked" : false,
      "code" : "pool"
    },
    {
      "name" : "Parking",
      "checked" : false,
      "code" : "parking"
    },
    {
      "name" : "Barbeque",
      "checked" : false,
      "code" : "barbeque"
    },
    {
      "name" : "Mountain View ",
      "checked" : false,
      "code" : "mountview"
    },
    {
      "name" : "View Balcony",
      "checked" : false,
      "code" : "balcony"
    },
    {
        "name" : "River Side",
        "checked" : false,
        "code" : "riverside"
    },
    {
        "name" : "View Balcony",
        "checked" : false,
        "code" : "balcony"
    },
    {
        "name" : "River Side",
        "checked" : false,
        "code" : "riverside"
    },
  ]
