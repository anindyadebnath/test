


export default function ZCarousel(props) {
  
    return (
            <div id={props.id} className={"carousel slide " + props.divClass} data-bs-ride="carousel">
              <div className="carousel-indicators">
                {props.images && props.images.length > 0 && props.images.map((e,i)=> {
                  return <button key={i} type="button" data-bs-target={'#'+props.id} data-bs-slide-to={i} className={i==0 ?'active':''} aria-current="true" aria-label={"Slide "+i}></button>
                })}

                {/* <button type="button" data-bs-target={'#'+props.id} data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target={'#'+props.id} data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target={'#'+props.id} data-bs-slide-to="2" aria-label="Slide 3"></button>
               */}
              </div>

              <div className="carousel-inner">
                {props.images && props.images.length > 0 && props.images.map((e,i)=> {
                  return (
                    <div key={i} className={i==0 ? 'carousel-item active' : 'carousel-item'}>
                      <img src= {e.imgLink} className="d-block w-100" alt={e.title}/>
                      <div className="carousel-caption">
                        {e.title}
                      </div>
                    </div>
                    )
                  })
                }
                {/* <div className="carousel-item active">
                  <img src="https://images.pexels.com/photos/346529/pexels-photo-346529.jpeg" className="d-block w-100" alt="..."/>
                  <div className="carousel-caption">
                    Batasia Loop
                  </div>
                </div>
                <div className="carousel-item">
                  <img src="https://images.pexels.com/photos/1107717/pexels-photo-1107717.jpeg" className="d-block w-100" alt="..."/>
                  <div className="carousel-caption">
                  Lamahat
                  </div>
                </div>
                <div className="carousel-item">
                  <img src="https://images.pexels.com/photos/2662116/pexels-photo-2662116.jpeg" className="d-block w-100" alt="..."/>
                  <div className="carousel-caption">
                  Ghoom Monestry
                  </div>
                </div> */}
              </div>
              {!props.id.includes('stayCard') && <>
              <button className="carousel-control-prev" type="button" data-bs-target={'#'+props.id} data-bs-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Previous</span>
              </button>
              <button className="carousel-control-next" type="button" data-bs-target={'#'+props.id} data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Next</span>
              </button>
              </>}
        </div>
    );
}