import React from 'react'
import { Button } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';

function ZCard(props) {
  return (
    <div className='zcard-container'>
        <Card onClick={props.onClick} style={{ margin: '5px'}}>
        <Card.Img variant="top" className='zcard-img' src={props.imageLink} />
        {props.subtitle &&  <Card.Subtitle>{props.subtitle}</Card.Subtitle>}
        <Card.Body>
          {props.title && <Card.Title>{props.title}</Card.Title>}
          <Card.Footer>
              {props.body}
          </Card.Footer>
          {props.btnLabel && <Button onClick={()=> props.btnAction} variant="primary">{props.btnLabel}</Button>}
        </Card.Body>
      </Card>
    </div>
    
  )
}

export default ZCard