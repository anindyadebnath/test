import React from 'react'
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { Link } from 'react-router-dom';

function ZBreadCrumb(props) {
  return (
    <Breadcrumb>
        {Object.values(props.links).map((e,i)=> {
           return <Breadcrumb.Item key={i} active={e.active} linkAs={!e.active && Link} linkProps={!e.active && e.linkProps}>{e.title}</Breadcrumb.Item>
        })}
    </Breadcrumb>
  )
}

export default ZBreadCrumb