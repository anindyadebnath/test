import { json, useLoaderData } from "@remix-run/react";
import HomePage, {links as homePageCss} from "../components/home/HomePage";
import { getHomePageAllStays,getHomePageTourPackageCard,getPlacesDetails } from "../util/ZAxios";
import { useEffect } from "react";

export const meta = () => {
  return [
    { title: "My app" },
    { name: "description", content: "Welcome to my app!" },
  ];
};

export default function Index() {

  let {places,tourPackages,stays} = useLoaderData();
  
  return (
    <HomePage 
    stays={stays}
    tourPackages={tourPackages}
    places={places}
    />
  );
}

export async function loader() {
  
  const promoStays = await getHomePageAllStays()
  const promoPackage = await  getHomePageTourPackageCard()
  const promoPlaces = await  getPlacesDetails()


  return json(
    {
      places: promoPlaces.data,
      tourPackages: promoPackage.data,
      stays: promoStays.data
    }
  )
}

export function links() {
  return [...homePageCss()];
}