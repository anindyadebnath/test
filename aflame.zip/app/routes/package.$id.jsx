import { json, useLoaderData } from "@remix-run/react";
import PackageDetails, {links as packageDetailsCss} from "../components/package-util/z-timeLine/PackageDetails";
import { getPackageByCode } from "../util/ZAxios";

export const meta = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function PackageDetailsRoute() {

  const packageData = useLoaderData()
  
  return (
    <PackageDetails
      packageData = {packageData.tourPackageDto}
      otherPackages = {packageData.homePagePackageCard}
    />
  );
}

export function links() {
  return [...packageDetailsCss()]
}

export async function loader({params}) {
  const res = await getPackageByCode(params.id)
  return json(res.data)
}
