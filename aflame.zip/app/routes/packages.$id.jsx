import { json, useLoaderData } from "@remix-run/react";
import TourPackages, {links as tourPackagesCss} from "../components/tour-packages/TourPackages";
import { getPackagesByPlaceCode } from "../util/ZAxios";

export const meta = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function PackagesRoute() {

  const packagesData = useLoaderData()
  
  return (
    <TourPackages
    packagesData = {Object.values(packagesData)}
    />
  );
}

export function links() {
  return [...tourPackagesCss()]
}

export async function loader({params}) {
  const res = await getPackagesByPlaceCode(params.id)
  return json(res.data)
}
