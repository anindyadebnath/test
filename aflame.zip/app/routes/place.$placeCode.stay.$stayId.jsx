import { json, useLoaderData } from "@remix-run/react";
import { getStayByStayCode } from "../util/ZAxios";
import Stay, {links as stayCss} from "../components/stay/Stay";

export const meta = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function PlaceStaysRoute() {

  const stayData = useLoaderData();
  
  return (
    <Stay 
    stayData={stayData}
    />
  );
}

export async function loader({params}) {
  const stayRes = await getStayByStayCode(params.stayId)
  return json(stayRes.data)
}

export function links() {
  return [...stayCss()]
}