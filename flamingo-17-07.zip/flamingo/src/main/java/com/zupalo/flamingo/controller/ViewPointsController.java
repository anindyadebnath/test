package com.zupalo.flamingo.controller;


import com.zupalo.flamingo.model.Destination;
import com.zupalo.flamingo.model.ViewPoint;
import com.zupalo.flamingo.repository.DestinationRepository;
import com.zupalo.flamingo.repository.ViewPointRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET})
@RestController()
public class ViewPointsController {

    @Autowired
    private ViewPointRepository viewPointRepository;

    @GetMapping("view-point/{code}")
    ResponseEntity<ViewPoint> getViewPoint(@PathVariable String code) throws InterruptedException {
        return ResponseEntity.ok(viewPointRepository.findByPlaceCode(code));
    }
}
