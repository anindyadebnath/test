package com.zupalo.flamingo.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;


@Document("allstays")
@Data
public class Stay {

    private String name;
    private String code;
    private Destination destination;
    private String addeess;
    private String locHelp;
    private String[] attractions;
    private String[] amenities;
    private String distFromNear;
    private String[] tags;
    private String description;
    private String shortDesc;
    private String thumbnail;
    private StayImages[] images;
    private String[] fourImages;
    private StayTimings timings;
    private StayTariff[] tariff;
    private int[] impPolicy;
    private int price;
    private int discount;
    private boolean isActive;
    private boolean isDeleted;
}
