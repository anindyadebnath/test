package com.zupalo.flamingo.repository;

import com.zupalo.flamingo.model.PromoteStay;
import com.zupalo.flamingo.model.TourPackage;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PromoteStaysRepository extends MongoRepository<PromoteStay, String> {
}
