package com.zupalo.flamingo.dto;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class HomePagePackageCard {
    private String imageLink;
    private String duration;
    private String code;
    private int price;
    private String title;
    private String locationDays;
    private boolean isCustomisable;
    private boolean weekendTrip;
}
