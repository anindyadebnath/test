package com.zupalo.flamingo.model;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("stay-query")
@Data
@Builder
public class StayQuery {
    private String name;
    private String email;
    private String checkIn;
    private String checkOut;
    private Integer adults;
    private Integer kids;
    private Integer babies;
    private String phNumber;
    private String comments;
    private String stayCode;
    private Boolean deleted;
    private String created;
    private String qId;
}
