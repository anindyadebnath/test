package com.zupalo.flamingo.dto;

import com.zupalo.flamingo.model.Stay;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class StayQueryDto {
    private String name;
    private String email;
    private String checkIn;
    private String checkOut;
    private Integer adults;
    private Integer kids;
    private Integer babies;
    private String phNumber;
    private String comments;
    private String stayCode;
}
