package com.zupalo.flamingo.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("promote-stays")
public class PromoteStay {
    private boolean promoted;
    private String code;
}
