package com.zupalo.flamingo.model;

import lombok.Data;

@Data
public class StayImages {
    private String tag;
    private String imgLink;
}
