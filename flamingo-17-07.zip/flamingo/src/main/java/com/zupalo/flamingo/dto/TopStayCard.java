package com.zupalo.flamingo.dto;

import com.zupalo.flamingo.model.StayImages;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class TopStayCard {
    private String code;
    private String name;
    private String shortDesc;
    private String location;
    private String locHelp;
    private String locationCode;
    private String[] amenities;
    private String thumbnail;
    private int discount;
    private int price;
    private int finalPrice;
    private List<StayImages> images;
}
