package com.zupalo.flamingo.controller;


import com.zupalo.flamingo.dto.PlaceDto;
import com.zupalo.flamingo.mapper.DestinationMapper;
import com.zupalo.flamingo.model.Destination;
import com.zupalo.flamingo.repository.DestinationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET})
@RestController()
public class DestinationController {

    @Autowired
    private DestinationRepository destinationRepository;

    @Autowired
    private DestinationMapper destinationMapper;

    @GetMapping("places")
    ResponseEntity<List<Destination>> getPlaces() {
        return ResponseEntity.ok(destinationRepository.findAll());
    }

    @GetMapping("places/offbeat")
    ResponseEntity<List<PlaceDto>> getOffBeatPlaces() {
        return ResponseEntity.ok(destinationMapper.dBDestinationToPlace(
                destinationRepository.findOffbeatPlacesByParentLoc("darjeeling")));
    }
}
