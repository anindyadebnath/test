package com.zupalo.flamingo.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class StaticData {

    public static Map<Integer,String> inclusions = Map.ofEntries(
            Map.entry(1,"Intercity Car Transfers"),
            Map.entry(2,"3 Star Hotels"),
            Map.entry(3,"Pick up and drop from nearest Airport/Rail Station"),
            Map.entry(4,"Selected Meals"),
            Map.entry(5,"Night accommodation"),
            Map.entry(6,"All tours and transfers by Private NON-AC sedan vehicle"),
            Map.entry(7,"All major attractions and local sight-seeing"),
            Map.entry(8,"All toll tax parking charges, driver allowance etc"),
            Map.entry(9,"Accommodation Deluxe Room Ac / Non Ac"),
            Map.entry(10,"Mechanised well maintained Boat with beds and European Toilet"),
            Map.entry(11,"All major meals like Breakfast, Lunch, Evening tea Snacks, Dinner bed tea."),
            Map.entry(12,"Evening Cultural Programme"),
            Map.entry(13,"Boat permits and Still Camera permissions"),
            Map.entry(14,"Camp Fire (Winter Season Only)")
    );

    public static Map<Integer,String> exclusions = Map.ofEntries(
            Map.entry(1,"Upgrade to hotel/room category"),
            Map.entry(2,"All meals"),
            Map.entry(3,"Heaters"),
            Map.entry(4,"Camera fees"),
            Map.entry(5,"Airfare/train fares"),
            Map.entry(6,"Travel insurance"),
            Map.entry(7,"Laundry/telephone bills/shopping/personal expenditure"),
            Map.entry(8,"Optional sight seeing/Cab other than what is covered"),
            Map.entry(9,"Adventure activities"),
            Map.entry(10,"Any Hard or Aerated Drinks"),
            Map.entry(11,"Any miscellaneous expenses incurred by the guests"),
            Map.entry(12,"Coolie Charge"),
            Map.entry(13,"Non Indian guests will have to pay separately for the Permit fees inside the Tiger Reserve")
    );

    public static List<String> getInclusions(Integer[] nums) {
        List<String> list = new ArrayList<>();
        for(int i :nums) {
            list.add(inclusions.get(i));
        }
        return list;
    }

    public static List<String> getExclusions(Integer[] nums) {
        List<String> list = new ArrayList<>();
        for(int i :nums) {
            list.add(exclusions.get(i));
        }
        return list;
    }
}
