package com.zupalo.flamingo.controller;


import com.zupalo.flamingo.dto.PlaceDto;
import com.zupalo.flamingo.dto.StayQueryDto;
import com.zupalo.flamingo.mapper.DestinationMapper;
import com.zupalo.flamingo.model.Destination;
import com.zupalo.flamingo.model.StayQuery;
import com.zupalo.flamingo.repository.DestinationRepository;
import com.zupalo.flamingo.repository.QueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET,RequestMethod.POST})
@RestController()
public class StayQueryController {

    @Autowired
    private QueryRepository queryRepository;

    @PostMapping("query/stay")
    ResponseEntity<String> submitStayQuery(@RequestBody StayQueryDto dto)  {
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        String today = format.format(new Date());

        StayQuery query = StayQuery.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .checkIn(dto.getCheckIn())
                .checkOut(dto.getCheckOut())
                .adults(dto.getAdults())
                .kids(dto.getKids())
                .babies(dto.getKids())
                .phNumber(dto.getPhNumber())
                .comments(dto.getComments())
                .stayCode(dto.getStayCode())
                .deleted(false)
                .created(today)
                .qId(UUID.randomUUID().toString())
                .build();

    queryRepository.save(query);

    return ResponseEntity.ok("success");
    }
}
