package com.zupalo.flamingo.model;


import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document("tour-packages")
@Data
public class TourPackage {

    private String title;
    private String thumbnailImage;
    private String locationDays;
    private int price;
    private String code;
    private String titleWithDays;
    private String shortDuration;
    private String duration;
    private boolean isCustomisable;
    private boolean isScheduled;
    private boolean isPromoted;
    private Integer[] shortInclusion;
    private String[] shortVisits;
    private String[] images;
    private Integer[] inclusion;
    private Integer[] exclusion;
    private String upcomingTourDates;
    private String provider;
    private String contact;
    private String[] placeCodes;
    private PackageItinerary[] itinerary;
    private boolean weekendTrip;
}
