package com.zupalo.flamingo.mapper;

import com.zupalo.flamingo.dto.PlaceDto;
import com.zupalo.flamingo.model.Destination;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DestinationMapper {

    public List<PlaceDto> dBDestinationToPlace(List<Destination> destinationList) {
        List<PlaceDto> list = new ArrayList<>();
        destinationList.forEach(d-> {
            PlaceDto dto = PlaceDto.builder()
                            .code(d.getCode())
                            .name(d.getName())
                            .thumbnail(d.getThumbnail())
                            .build();
            list.add(dto);
        });
    return list;
    }
}
