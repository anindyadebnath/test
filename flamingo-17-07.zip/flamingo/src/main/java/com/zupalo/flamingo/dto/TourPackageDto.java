package com.zupalo.flamingo.dto;


import com.zupalo.flamingo.model.PackageItinerary;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class TourPackageDto {

    private String title;
    private String locationDays;
    private int price;
    private String code;
    private String titleWithDays;
    private String shortDuration;
    private String duration;
    private boolean isCustomisable;
    private boolean isScheduled;
    private List<String> images;
    private List<String> inclusion;
    private List<String> exclusion;
    private String upcomingTourDates;
    private String provider;
    private String contact;
    private List<String> placeCodes;
    private List<PackageItinerary> itinerary;
}
