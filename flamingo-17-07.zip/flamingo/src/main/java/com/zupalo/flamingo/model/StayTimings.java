package com.zupalo.flamingo.model;

import lombok.Data;

@Data
public class StayTimings {
    private String checkIn;
    private String checkOut;
}
