package com.zupalo.flamingo.dto;

import com.zupalo.flamingo.model.Stay;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PlaceDto {
    private String code;
    private String name;
    private String thumbnail;
}
