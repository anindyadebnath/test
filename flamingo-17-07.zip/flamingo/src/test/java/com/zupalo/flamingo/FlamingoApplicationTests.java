package com.zupalo.flamingo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlamingoApplicationTests {

	@Test
	void contextLoads() {
	}

}
